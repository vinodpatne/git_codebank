package com.logmanager.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Opcode_Service_Mapping")
public class OpcodeServiceMapping {

    @Id
    @Column(name = "OPCODE")
    private String OPCODE;

    @Column(name = "SERVICE")
    private String SERVICE;

    public String getOPCODE() {
	return OPCODE;
    }

    public void setOPCODE(String opcode) {
	OPCODE = opcode;
    }

    public String getSERVICE() {
	return SERVICE;
    }

    public void setSERVICE(String service) {
	SERVICE = service;
    }

}
