package com.logmanager.pojo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TIME_AUDIT")
public class TimeAudit {

    @Id
    @Column(name = "Transaction_ID")
    private String Transaction_ID;

    @Column(name = "Time_Stamp")
    private String Time_Stamp;

    @Column(name = "Session_Id")
    private String Session_Id;

    @Column(name = "Business_ID")
    private String Business_ID;

    @Column(name = "Mobile_Number")
    private String Mobile_Number;

    @Column(name = "Opcode")
    private String Opcode;

    @Column(name = "Response")
    private String Response;

    @Column(name = "Respose_Code")
    private String Respose_Code;

    @Column(name = "SHM_Response_Time")
    private String SHM_Response_Time;

    @Column(name = "BEM_Response_Time")
    private String BEM_Response_Time;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "timeaudit")
    private Set<ServiceBreakup> serviceBreakupList;

    public String getTransaction_ID() {
	return Transaction_ID;
    }

    public void setTransaction_ID(String transaction_ID) {
	Transaction_ID = transaction_ID;
    }

    public String getTime_Stamp() {
	return Time_Stamp;
    }

    public void setTime_Stamp(String time_Stamp) {
	Time_Stamp = time_Stamp;
    }

    public String getSession_Id() {
	return Session_Id;
    }

    public void setSession_Id(String session_Id) {
	Session_Id = session_Id;
    }

    public String getBusiness_ID() {
	return Business_ID;
    }

    public void setBusiness_ID(String business_ID) {
	Business_ID = business_ID;
    }

    public String getMobile_Number() {
	return Mobile_Number;
    }

    public void setMobile_Number(String mobile_Number) {
	Mobile_Number = mobile_Number;
    }

    public String getOpcode() {
	return Opcode;
    }

    public void setOpcode(String opcode) {
	Opcode = opcode;
    }

    public String getResponse() {
	return Response;
    }

    public void setResponse(String response) {
	Response = response;
    }

    public String getRespose_Code() {
	return Respose_Code;
    }

    public void setRespose_Code(String respose_Code) {
	Respose_Code = respose_Code;
    }

    public String getSHM_Response_Time() {
	return SHM_Response_Time;
    }

    public void setSHM_Response_Time(String response_Time) {
	SHM_Response_Time = response_Time;
    }

    public String getBEM_Response_Time() {
	return BEM_Response_Time;
    }

    public void setBEM_Response_Time(String response_Time) {
	BEM_Response_Time = response_Time;
    }

    public Set<ServiceBreakup> getServiceBreakupList() {
	return serviceBreakupList;
    }

    public void setServiceBreakupList(Set<ServiceBreakup> serviceBreakupList) {
	this.serviceBreakupList = serviceBreakupList;
    }

}
