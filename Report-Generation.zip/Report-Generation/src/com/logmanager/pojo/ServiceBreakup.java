package com.logmanager.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BEM_SERVICE_BREAKUP")
public class ServiceBreakup {

    @Id
    @Column(name = "ID")
    private int ID;

    @Column(name = "Transaction_ID")
    private String Transaction_ID;

    @Column(name = "Time_Stamp")
    private String Time_Stamp;

    @Column(name = "ServiceId")
    private String ServiceId;

    @Column(name = "ConsumerRefNo")
    private String ConsumerRefNo;

    @Column(name = "CategoryId")
    private String CategoryId;

    @Column(name = "Response")
    private String Response;

    @Column(name = "Service_Time")
    private String Service_Time;

    @Column(name = "BemError")
    private String BemError;

    @Column(name = "Host")
    private String Host;

    @Column(name = "PP_Error_Code")
    private String PP_Error_Code;

    @Column(name = "PP_Error_Desc")
    private String PP_Error_Desc;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Transaction_ID", nullable = false, insertable = false, updatable = false)
    private TimeAudit timeaudit;

    public String getTransaction_ID() {
	return Transaction_ID;
    }

    public void setTransaction_ID(String transaction_ID) {
	Transaction_ID = transaction_ID;
    }

    public String getTime_Stamp() {
	return Time_Stamp;
    }

    public void setTime_Stamp(String time_Stamp) {
	Time_Stamp = time_Stamp;
    }

    public String getServiceId() {
	return ServiceId;
    }

    public void setServiceId(String serviceId) {
	ServiceId = serviceId;
    }

    public String getConsumerRefNo() {
	return ConsumerRefNo;
    }

    public void setConsumerRefNo(String consumerRefNo) {
	ConsumerRefNo = consumerRefNo;
    }

    public String getCategoryId() {
	return CategoryId;
    }

    public void setCategoryId(String categoryId) {
	CategoryId = categoryId;
    }

    public String getResponse() {
	return Response;
    }

    public void setResponse(String response) {
	Response = response;
    }

    public String getService_Time() {
	return Service_Time;
    }

    public void setService_Time(String service_Time) {
	Service_Time = service_Time;
    }

    public String getBemError() {
	return BemError;
    }

    public void setBemError(String bemError) {
	BemError = bemError;
    }

    public String getHost() {
	return Host;
    }

    public void setHost(String host) {
	Host = host;
    }

    public String getPP_Error_Code() {
	return PP_Error_Code;
    }

    public void setPP_Error_Code(String error_Code) {
	PP_Error_Code = error_Code;
    }

    public String getPP_Error_Desc() {
	return PP_Error_Desc;
    }

    public void setPP_Error_Desc(String error_Desc) {
	PP_Error_Desc = error_Desc;
    }

    public TimeAudit getTimeaudit() {
	return timeaudit;
    }

    public void setTimeaudit(TimeAudit timeaudit) {
	this.timeaudit = timeaudit;
    }

    public int getID() {
	return ID;
    }

    public void setID(int id) {
	ID = id;
    }

}
