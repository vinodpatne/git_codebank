package com.logmanager.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.logmanager.service.LogManagerService;

@Controller
// @RequestMapping("/Report-Generation")
public class LoginController {

    @Autowired(required = true)
    LogManagerService logManagerService;

    List<String> filePaths = new ArrayList<String>();
    public static Map<String, Double> sHMAverageMap;

    @RequestMapping(value = "/spring", method = RequestMethod.GET)
    public ModelAndView handleHomePageRequest(HttpServletRequest request, HttpServletResponse response) {
	System.out.println("I am here +++++++++++++++");
	return new ModelAndView("/WEB-INF/jsp/home.jsp", "myModel", null);
    }

    @RequestMapping(value = "/Login123", method = RequestMethod.POST)
    public ModelAndView handleGetReportRequest(HttpServletRequest request, HttpServletResponse response, ModelMap model) {

	// String response = logManagerService.verifyLogin(userName, password);

	// logManagerService.prepareServiceCountGraph(request.getSession().getServletContext().getRealPath("images"), filePaths);
	// java.net.URL r = this.getClass().getClassLoader().getResource("images");
	// String filePath = r.getFile();
	// logManagerService.prepareServiceCountGraph(filePath, filePaths);
	System.out.println("Done");
	logManagerService.prepareServiceCountGraph(filePaths);
	logManagerService.prepareHLFGraph(filePaths);
	logManagerService.prepareTransactionFailuresGraph(filePaths);
	logManagerService.prepareSHMPerformanceGraph(filePaths, sHMAverageMap);
	logManagerService.prepareUserResponseGraph(filePaths);
	logManagerService.preparePieChart(filePaths);
	logManagerService.prepareBEMPerformanceGraph(filePaths);
	// logManagerService.sendEmailService();

	//
	// if (response1.equalsIgnoreCase("success")) {
	// String msg = "Welcome to DefectCenter";
	// model.addAttribute("Message", msg);
	// return "success";
	// }
	//
	// return "failure";
	// }

	return new ModelAndView("/WEB-INF/jsp/success.jsp", "msg", "sucess");

    }
}