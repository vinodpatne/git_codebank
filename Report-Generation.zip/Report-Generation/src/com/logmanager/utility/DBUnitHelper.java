package com.logmanager.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.csv.CsvDataSet;
import org.dbunit.operation.DatabaseOperation;

/**
 * <DL>
 * <DT><B>Description:</B></DT>
 * <DD>This class helps to perform database operations based on the configuration provided in the config file.</DD>
 * </DL>
 * <DL>
 * <DT><B>Creation Date:</B></DT>
 * <DD>Jan 2, 2006</DD>
 * </DL>
 * 
 * @author vinod patne
 * @version 1.0
 */
public class DBUnitHelper {

    private static String QUEUE_CONFIG_FILE_NAME = "database.properties";

    private static Properties properties = null;

    private static String driverName = null;

    private static String connectionURL = null;

    private static String dataTypeFactoryName = null;

    private static String operation = null;

    private static String userName = null;

    private static String pwd = null;

    private static String schema = null;

    private static String sourceDirName = null;

    private static DBUnitHelper self = new DBUnitHelper();

    public DBUnitHelper() {

	FileInputStream fileInputStream = null;
	properties = new Properties();

	try {
	    fileInputStream = new FileInputStream(getFile(QUEUE_CONFIG_FILE_NAME));
	    properties.load(fileInputStream);
	    driverName = properties.getProperty("driver");
	    connectionURL = properties.getProperty("connectionURL");
	    dataTypeFactoryName = properties.getProperty("dataTypeFactory");
	    userName = properties.getProperty("userName");
	    pwd = properties.getProperty("userPassword");
	    schema = properties.getProperty("schema");

	    sourceDirName = properties.getProperty("sourceDir");

	    System.out.println("\n\nDatabase properties :\n");
	    System.out.println("\t driverName= " + driverName);
	    System.out.println("\t connectionURL= " + connectionURL);
	    System.out.println("\t userName= " + userName.toUpperCase() + "\n\n");

	    System.out.println("\t sourceDir= " + sourceDirName.toUpperCase() + "\n");

	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	} catch (IOException e) {
	    e.printStackTrace();
	} finally {
	    if (fileInputStream != null) {
		try {
		    fileInputStream.close();
		} catch (IOException e1) {
		    e1.printStackTrace();
		}
	    }
	}
    }

    public static void main(String[] args) throws Exception {

	String fileName = "";

	if (args.length == 2) {
	    fileName = args[0];
	    operation = args[1];
	}

	if (args.length == 1) {
	    fileName = args[0];
	    operation = "refresh";
	}

	String setupQueries[] = new String[] { "" };

	String teardownQueries[] = new String[] { "" };

	// Initialize
	/*
	 * for (int index = 0; index < setupQueries.length; index++) { try { executeQuery(schema, setupQueries[index]); } catch (Exception e) {
	 * e.printStackTrace(); } }
	 */
	if (fileName == null || !(fileName.trim().length() > 0) || !checkFileExsist(fileName)) {

	    File sourceDir = null;
	    if (sourceDirName != null && (sourceDirName = sourceDirName.trim()).length() > 0) {
		sourceDir = new File(sourceDirName);
	    } else {
		sourceDir = new File("./data");
	    }
	    System.out.println(":: Using '" + sourceDir.getAbsolutePath() + "' as source data directory.\n\n");
	    processDirectory(sourceDir);

	} else {
	    System.out.print("Enter selection (insert,delete,refresh) and press enter: ");
	    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	    operation = br.readLine();
	    br = null;
	    // String fname = "test.csv";
	    processFile(fileName, operation);
	}

	/*
	 * // Clean up for (int index = 0; index < setupQueries.length; index++) { try { executeQuery("TAPS", teardownQueries[index]); } catch
	 * (Exception e) { e.printStackTrace(); } }
	 */

	System.out.println("\n\nDone...");
    }

    public static void processDirectory(File sourceDir) throws Exception {
	File[] filesAndDirs = sourceDir.listFiles();

	if (filesAndDirs == null || filesAndDirs.length == 0) {
	    System.out.println("ERROR: No files found in " + sourceDir.getAbsolutePath() + " folder.");
	    return;
	    // System.exit(0);
	}

	List<File> filesDirs = Arrays.asList(filesAndDirs);
	Iterator<File> filesIter = filesDirs.iterator();
	int counter = 1;

	while (filesIter.hasNext()) {
	    File file = (File) filesIter.next();
	    String currFileName = file.getName();
	    if (currFileName.endsWith(".xls") || currFileName.endsWith(".xlsx") || currFileName.endsWith(".csv") || currFileName.endsWith(".xml")) {
		System.out.println((counter++) + ": " + file.getParent() + "\\" + currFileName);

		processFile(currFileName, "insert");
		// System.out.print("Do you wish to refresh the data of this file(y/n): ");
		// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		// String ans = br.readLine();
		// br = null;

	    } else if (file.isDirectory()) {
		processDirectory(file);
	    } else {
		System.out.println("\n WARN: Skipped '" + currFileName + "' file.\n");
	    }
	}
    }

    public static void processFile(File file, String operation) throws Exception {
	processFile(file.getAbsolutePath(), operation);
    }

    public static void processFile(String fileName, String operation) throws Exception {
	if (operation.equalsIgnoreCase("insert")) {
	    DBUnitHelper.getInstance().insert(fileName);
	}
    }

    public static boolean checkFileExsist(String fileName) throws FileNotFoundException {
	File file = getFile(fileName.trim());
	if (!file.exists()) {
	    return false;
	}
	return true;
    }

    /**
     * Returns singletone instance of DBUnitHelper.
     * 
     * @return Singletone instance of DBUnitHelper.
     */
    public static DBUnitHelper getInstance() {
	return self;
    }

    /**
     * @param fileName
     * @throws Exception
     */

    public void insert(String fileName) throws Exception {
	System.out.println("Start INSERT operation.");
	doOperation(DatabaseOperation.INSERT, fileName);
    }

    /**
     * @param fileName
     * @throws Exception
     */
    public static void executeQuery(String schemaName, String command) throws Exception {
	if (command.trim().length() == 0) {
	    return;
	}

	System.out.println("Start executeQuery operation.");

	Connection conn = null;
	try {
	    conn = getDBConnection(schemaName);
	    if (conn == null) {
		System.err.println("Connection is null");
		System.exit(0);
	    }
	    Statement statement = conn.createStatement();
	    statement.execute(command);

	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    if (conn != null) {
		System.out.println("\tRelease connection.");
		conn.close();
	    }
	    conn = null;
	}

    }

    /**
     * @param oper
     * @param fileName
     * @throws Exception
     */
    private void doOperation(DatabaseOperation oper, String fileName) throws Exception {
	IDatabaseConnection conn = null;
	try {
	    conn = getConnection(schema);
	    if (conn == null) {
		System.err.println("Connection is null.");
		System.exit(0);
	    }

	    oper.execute(conn, getDataSet(fileName));
	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    if (conn != null) {
		conn.close();
	    }
	    conn = null;
	}
    }

    /**
     * @param fileName
     * @return
     * @throws Exception
     */
    private IDataSet getDataSet(String fileName) throws Exception {
	// XlsDataSet ds = new XlsDataSet(new File("./data/node1/Project_Tracking_Data_v0 1.xls"));
	CsvDataSet ds = new CsvDataSet(new File("./data/node/"));
	return ds;
    }

    /**
     * @return
     * @throws Exception
     */
    private static Connection getDBConnection(String schemaName) throws Exception {

	Connection conn = null;
	DatabaseConfig config = null;

	Class.forName(driverName);
	conn = DriverManager.getConnection(connectionURL, userName, pwd);

	System.out.println("\t Got connected to '" + connectionURL + "'.");

	return conn;
    }

    /**
     * @return
     * @throws Exception
     */
    private IDatabaseConnection getConnection(String schemaName) throws Exception {

	IDatabaseConnection dbConn = null;
	Connection conn = null;
	DatabaseConfig config = null;

	Class.forName(driverName);
	conn = DriverManager.getConnection(connectionURL, userName, pwd);

	if (schemaName != null) {
	    dbConn = new DatabaseConnection(conn, schemaName);
	} else {
	    dbConn = new DatabaseConnection(conn);
	}

	Class dataTypeFactoryClass = Class.forName(dataTypeFactoryName);

	config = dbConn.getConfig();
	config.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, dataTypeFactoryClass.newInstance());

	System.out.println("\t Got connected to '" + connectionURL + "'.\n");

	return dbConn;
    }

    /**
     * @return Returns the driverName.
     */
    public String getDriverName() {
	return driverName;
    }

    /**
     * @return Returns the pwd.
     */
    public String getPwd() {
	return pwd;
    }

    /**
     * @param pwd
     *            The pwd to set.
     */
    public void setPwd(String pwd) {
	this.pwd = pwd;
    }

    /**
     * @return Returns the connectionURL.
     */
    public String getConnectionURL() {
	return connectionURL;
    }

    /**
     * @param connectionURL
     *            The connectionURL to set.
     */
    public void setConnectionURL(String url) {
	this.connectionURL = url;
    }

    /**
     * @return Returns the userName.
     */
    public String getUserName() {
	return userName;
    }

    /**
     * @param userName
     *            The userName to set.
     */
    public void setUserName(String userName) {
	this.userName = userName;
    }

    /**
     * @return Returns the operation.
     */
    public String getOperation() {
	return operation;
    }

    /**
     * @param operation
     *            The operation to set.
     */
    // public void setOperation(String operation) {
    // this.operation = operation;
    // }
    public static File getFile(String sourceFile) throws FileNotFoundException {
	System.out.println("sourceFile=" + sourceFile);
	File file = new File(sourceFile);
	if (!file.exists()) {
	    URL url = Thread.currentThread().getContextClassLoader().getResource(sourceFile);
	    if (url == null) {
		throw new FileNotFoundException("File (" + sourceFile + ") not found in the classpath");
	    }
	    String strFileName = url.getFile();
	    int index = -1;
	    do {
		index = strFileName.indexOf("%20");
		if (index != -1) {
		    StringBuffer strFileNameBuffer = new StringBuffer(strFileName);
		    strFileNameBuffer.replace(index, index + 3, " ");
		    strFileName = strFileNameBuffer.toString();
		}
	    } while (index != -1);

	    file = new File(strFileName);
	}
	return file;
    }
}
