package com.logmanager.utility;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;

public class Encrypter {

    /** Constant ALGORITHM. */
    private final static String ALGORITHM = "SHA1PRNG";

    private final static String AES_ALGORITHM = "AES";

    public static void main(String[] args) {

	 System.out.println(System.getProperty("java.runtime.version"));
	 try {
			// Get IV and Key value from Static class
			String IV = "770A8A65DA156D24";
			String KEY = "990A8A65DA156D24";
			String MOBILENOTEXT = "2008934468";

			/*byte[] encrypt = null;
			encrypt = encrypt(IV.getBytes(), KEY.getBytes(), MOBILENOTEXT
					.getBytes());
			String hexEncodedUserName = String.valueOf(Hex.encodeHex(encrypt));

			System.out.println(" * hexEncodedMobile number ="
					+ hexEncodedUserName);*/

			byte[] byteArrayToDecrypt = null;
			byte[] decrypt = null;

			String hexEncodedUserName = "8c04a78615a8b7fe5020d37a142a418a";
			byteArrayToDecrypt =Hex.decodeHex(hexEncodedUserName.toCharArray());
//			byteArrayToDecrypt = Hex.decodeHex("f44553383cb0c00f34af813968166cb8".toCharArray());
			decrypt = decrypt(IV.getBytes(), KEY.getBytes(), byteArrayToDecrypt);
			System.out.println(" * decrypted mobile number ="
					+ new String(decrypt));

		} catch (Exception e) {
			e.printStackTrace();

		}

    }

    public static byte[] encrypt(byte[] ivBytes, byte[] keyBytes, byte[] mes) throws NoSuchAlgorithmException, NoSuchPaddingException,
	    InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
	AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
	SecretKeySpec newKey = new SecretKeySpec(keyBytes, AES_ALGORITHM);
	Cipher cipher = null;
	cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
	cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
	return cipher.doFinal(mes);
    }

    public static byte[] decrypt(byte[] ivBytes, byte[] keyBytes, byte[] bytes) throws NoSuchAlgorithmException, NoSuchPaddingException,
	    InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException,
	    ClassNotFoundException {
	AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
	SecretKeySpec newKey = new SecretKeySpec(keyBytes, AES_ALGORITHM);
	Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
	cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
	return cipher.doFinal(bytes);
    }

}
