package com.logmanager.service;

import java.util.List;
import java.util.Map;

public interface LogManagerService {

    // public void prepareServiceCountGraph(String contextPath, List<String> filePaths);

    public void prepareServiceCountGraph(List<String> filePaths);

    public void prepareHLFGraph(List<String> filePaths);

    public void prepareTransactionFailuresGraph(List<String> filePaths);

    public void prepareSHMPerformanceGraph(List<String> filePaths, Map<String, Double> averageMap);

    public void prepareUserResponseGraph(List<String> filePaths);

    public void preparePieChart(List<String> filePaths);

    public void prepareBEMPerformanceGraph(List<String> filePaths);

    public void sendEmailService();
}
