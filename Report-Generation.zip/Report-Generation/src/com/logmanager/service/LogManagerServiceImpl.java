package com.logmanager.service;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.logmanager.dao.LogManagerDao;

@Service
public class LogManagerServiceImpl implements LogManagerService {

    private static String USER_RESPONSE_TIME_CHART_NAME = "User_Response_Column_Chart.jpg";
    private static String USER_RESPONSE_TIME_TITLE = "User Response Per service";
    private static String SERVICE_COUNT_CHART_NAME = "Service_Counts_Column_Chart.jpg";
    private static String SERVICE_FAILURE_CHART_NAME = "Service_Failure_Chart.jpg";
    private static String FEATURE_RESPONSE_TIME_TITLE = "Feature Response-Time Audit";
    private static String FEATURE_RESPONSE_TIME_CHART_NAME = "Feature_Response_Column_Chart.jpg";
    private static String TRANSACTION_FAILURE_CHART_NAME = "Transaction_Failure_Response_Column_Chart.jpg";
    private static String TRANSACTION_FAILURE_TITLE = "Transaction Failure Count";
    private static String HOURLY_LOGIN_FREQUENCY_TITLE = "Hourly Unique-Logins Frequency";
    private static String BACKEND_PERFORMANCE_TITLE = "Backend Performance Response";
    private static String BACKEND_PERFORMANCE_CHART_NAME = "Backend_Performance_Response_Column_Chart.jpg";
    private static String HOURLY_LOGIN_FREQUENCY_CHART_NAME = "Hourly_Login_Frequency.jpg";

    private static final String TEMP_DIR_LOCATION = System.getProperty("java.io.tmpdir", "./");

    private static final String WEB_DIR_LOCATION = "C:/softtag/ProjectWorkspace/workspace_19aug/Report-Generation/WebContent/images";
    private static String SERVICE = "Service";
    private static String COMMA_SEPARATOR = ",";
    private static String SERVICE_COUNT_TITLE = "Service Count of the Day";
    private static String SERVICE_FAILURE_TITLE = "Service failure of the Day";

    private static Color BACKGROUND_COLOR = Color.white;
    private static Color BLUE = new Color(78, 131, 197);
    private static Color RED = new Color(194, 78, 79);
    private static Color GREEN = new Color(157, 187, 99);
    private static final String USER = "user";

    @Autowired(required = true)
    LogManagerDao logManagerdao;

    @Transactional
    public void prepareServiceCountGraph(List<String> filePaths) {

	String serviceCountFilePath = getFileName(SERVICE_COUNT_CHART_NAME, filePaths);
	DefaultCategoryDataset serviceCountDataset = logManagerdao.createServiceCountDataset();
	JFreeChart serviceCountChart = ChartFactory.createBarChart(SERVICE_COUNT_TITLE, SERVICE, SERVICE + "Count", serviceCountDataset,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot = getPlot(serviceCountChart);
	BarRenderer renderer = (BarRenderer) plot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesPaint(0, GREEN);

	try {
	    ChartUtilities.saveChartAsJPEG(new File(serviceCountFilePath), serviceCountChart, 1300, 800);
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    @Transactional
    public void prepareHLFGraph(List<String> filePaths) {

	String HourlyFrequencyFile = getFileName(HOURLY_LOGIN_FREQUENCY_CHART_NAME, filePaths);
	DefaultCategoryDataset hourlyLoginFrequencyDataset = logManagerdao.createHLFDataset();
	JFreeChart hLFChart = ChartFactory.createBarChart(HOURLY_LOGIN_FREQUENCY_TITLE, "Time (Hours)", SERVICE + " Count",
		hourlyLoginFrequencyDataset, PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot1 = getPlot(hLFChart);

	final CategoryItemRenderer renderer1 = plot1.getRenderer();

	renderer1.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer1.setSeriesItemLabelsVisible(0, true);

	try {
	    File graphFile = new File(HourlyFrequencyFile);
	    ChartUtilities.saveChartAsJPEG(graphFile, hLFChart, 1000, 800);
	    IOUtils.copy(new FileInputStream(graphFile), new FileOutputStream(new File(WEB_DIR_LOCATION + "/" + graphFile.getName())));
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    @Transactional
    public void prepareTransactionFailuresGraph(List<String> filePaths) {

	DefaultCategoryDataset transactionFailures = logManagerdao.createServiceFailureCountDataset();
	JFreeChart tFChart = ChartFactory.createBarChart(TRANSACTION_FAILURE_TITLE, SERVICE, "Failure Count", transactionFailures,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot2 = getPlot(tFChart);
	final CategoryItemRenderer renderer2 = plot2.getRenderer();

	renderer2.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer2.setSeriesItemLabelsVisible(0, true);
	renderer2.setSeriesPaint(0, RED);

	String TransactionFailureFile = getFileName(TRANSACTION_FAILURE_CHART_NAME, filePaths);
	try {
	    ChartUtilities.saveChartAsJPEG(new File(TransactionFailureFile), tFChart, 900, 700);
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    @Transactional
    public void prepareSHMPerformanceGraph(List<String> filePaths, Map<String, Double> averageMap) {
	DefaultCategoryDataset backendPerformance = logManagerdao.createPerformanceCountDataset(averageMap);
	JFreeChart chart = ChartFactory.createBarChart(FEATURE_RESPONSE_TIME_TITLE, SERVICE, "Response Time (sec)", backendPerformance,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot bemPerformancePlot = getPlot(chart);
	BarRenderer renderer = (BarRenderer) bemPerformancePlot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(1, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(2, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));

	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesItemLabelsVisible(1, true);
	renderer.setSeriesItemLabelsVisible(2, true);
	renderer.setSeriesPaint(0, BLUE);
	renderer.setSeriesPaint(1, RED);
	renderer.setSeriesPaint(2, GREEN);
	renderer.setSeriesPaint(3, new Color(128, 100, 159));

	renderer.setItemMargin(.002);

	int columnCount = backendPerformance.getColumnCount();
	String backendPerformanceFile = getFileName(FEATURE_RESPONSE_TIME_CHART_NAME, filePaths);
	int xDimension = columnCount * 100 < 1500 ? 1500 : (columnCount * 100);
	int yDimension = xDimension * 5 / 10;
	try {
	    ChartUtilities.saveChartAsJPEG(new File(backendPerformanceFile), chart, xDimension, yDimension);
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    @Transactional
    public void prepareUserResponseGraph(List<String> filePaths) {
	DefaultCategoryDataset userBackendPerformance = logManagerdao.createUserPerformanceCountDataset();
	JFreeChart chart = ChartFactory.createBarChart(USER_RESPONSE_TIME_TITLE, SERVICE, USER + "Count", userBackendPerformance,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot bemPerformancePlot = getPlot(chart);
	BarRenderer renderer = (BarRenderer) bemPerformancePlot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(1, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(2, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));

	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesItemLabelsVisible(1, true);
	renderer.setSeriesItemLabelsVisible(2, true);
	renderer.setSeriesPaint(0, BLUE);
	renderer.setSeriesPaint(1, RED);
	renderer.setSeriesPaint(2, GREEN);
	renderer.setSeriesPaint(3, new Color(128, 100, 159));

	renderer.setItemMargin(.002);

	int columnCount = userBackendPerformance.getColumnCount();
	String userBackendPerformanceFile = getFileName(USER_RESPONSE_TIME_CHART_NAME, filePaths);
	int xDimension = columnCount * 100 < 1500 ? 1500 : (columnCount * 100);
	int yDimension = xDimension * 5 / 10;
	try {
	    ChartUtilities.saveChartAsJPEG(new File(userBackendPerformanceFile), chart, xDimension, yDimension);
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    @Transactional
    public void preparePieChart(List<String> filePaths) {
	String serviceFailureFilePath = getFileName(SERVICE_FAILURE_CHART_NAME, filePaths);
	// DefaultPieDataset dataset = new DefaultPieDataset();
	DefaultPieDataset serviceFailureDataset = logManagerdao.createServiceFailureDataset();
	JFreeChart serviceFailureCountChart = ChartFactory.createPieChart(SERVICE_FAILURE_TITLE, serviceFailureDataset, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	// CategoryPlot plot = getPlot(serviceFailureCountChart);
	PiePlot plot = (PiePlot) serviceFailureCountChart.getPlot();
	setColor(plot, serviceFailureDataset);
	// plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
	plot.setNoDataMessage("No data available");

	try {
	    ChartUtilities.saveChartAsJPEG(new File(serviceFailureFilePath), serviceFailureCountChart, 1300, 800);
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    @Transactional
    public void prepareBEMPerformanceGraph(List<String> filePaths) {
	DefaultCategoryDataset backendPerformance = logManagerdao.createBPerformanceCountDataset();
	JFreeChart chart = ChartFactory.createBarChart(BACKEND_PERFORMANCE_TITLE, SERVICE, "Response Time (sec)", backendPerformance,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot bemPerformancePlot = getPlot(chart);
	BarRenderer renderer = (BarRenderer) bemPerformancePlot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(1, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(2, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));

	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesItemLabelsVisible(1, true);
	renderer.setSeriesItemLabelsVisible(2, true);
	renderer.setSeriesPaint(0, BLUE);
	renderer.setSeriesPaint(1, RED);
	renderer.setSeriesPaint(2, GREEN);
	renderer.setSeriesPaint(3, new Color(128, 100, 159));

	renderer.setItemMargin(.002);

	int columnCount = backendPerformance.getColumnCount();
	String backendPerformanceFile = getFileName(BACKEND_PERFORMANCE_CHART_NAME, filePaths);
	int xDimension = columnCount * 100 < 1500 ? 1500 : (columnCount * 100);
	int yDimension = xDimension * 5 / 10;
	try {
	    ChartUtilities.saveChartAsJPEG(new File(backendPerformanceFile), chart, xDimension, yDimension);
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    @Transactional
    public void sendEmailService() {
	String sendEmailMesage = logManagerdao.sendEmailCall();
    }

    public static void setColor(PiePlot plot, DefaultPieDataset dataset) {

	GradientPaint gp0 = new GradientPaint(1.0f, 1.0f, new Color(153, 51, 203), 0.3f, 2.1f, Color.lightGray);
	GradientPaint gp1 = new GradientPaint(0.5f, 0.5f, new Color(175, 122, 255), 0.0f, 0.0f, Color.lightGray);
	GradientPaint gp2 = new GradientPaint(0.5f, 0.5f, new Color(102, 204, 153), 0.0f, 0.0f, Color.lightGray);
	GradientPaint gp3 = new GradientPaint(1.0f, 1.0f, Color.gray, 0.3f, 2.1f, Color.lightGray);

	List<Comparable> keys = dataset.getKeys();
	// int aInt;

	for (int i = 0; i < keys.size(); i++) {
	    // aInt = i % this.color.length;
	    if (i == 0) {
		plot.setSectionPaint(keys.get(i), gp0);
		plot.setBackgroundPaint(gp3);
	    }
	    if (i == 1) {
		plot.setSectionPaint(keys.get(i), gp1);
	    }
	    if (i == 2) {
		plot.setSectionPaint(keys.get(i), gp2);
	    }
	}
    }

    private static String getFileName(String fileName, List<String> filePaths) {

	String filePath = TEMP_DIR_LOCATION + fileName;
	// filePaths.add(filePath);
	// System.out.println("++++++" + filePath);
	// return filePath;
	return filePath;
    }

    private static CategoryPlot getPlot(JFreeChart chart) {
	CategoryPlot plot = (CategoryPlot) chart.getPlot();
	CategoryAxis xAxis3 = (CategoryAxis) plot.getDomainAxis();

	xAxis3.setCategoryLabelPositions(CategoryLabelPositions.UP_45);

	TextTitle title = chart.getTitle();
	Font titleFont = new Font("TimesRoman", Font.BOLD, 25);
	title.setFont(titleFont);
	chart.setTitle(title);
	BarRenderer renderer = (BarRenderer) plot.getRenderer();
	renderer.setMaximumBarWidth(0.03);

	renderer.setDrawBarOutline(true);
	renderer.setBarPainter(new StandardBarPainter());
	renderer.setShadowVisible(false);
	renderer.setSeriesPaint(0, BLUE);
	plot.setRangeGridlinePaint(Color.gray);
	plot.setRangeGridlinesVisible(true);
	chart.setBackgroundPaint(BACKGROUND_COLOR);
	plot.setBackgroundPaint(BACKGROUND_COLOR);
	return plot;
    }

}
