package com.logmanager.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.time.DateUtils;
import org.hibernate.SessionFactory;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.logmanager.pojo.FileUtility;
import com.logmanager.pojo.OpcodeServiceMapping;
import com.logmanager.pojo.ServiceBreakup;
import com.logmanager.pojo.TimeAudit;

@Repository
public class LogManagerDaoImpl implements LogManagerDao {

    private static final String DATE = "<<DATE>>";
    private static final String SESSION = "<<session>>";
    private static final String SELF_REG_COUNT = "<<self_reg_count>>";
    private static final String REG_USER_COUNT = "<<reg_user>>";
    public static int UNREGISTER_USER_CNT = 0;
    private static String COMMA_SEPARATOR = ",";
    private static String SERVICE = "Service";
    private static Map<String, String> opCodetoService;
    private static final String UNREGISTREDUSERS = "UnRegistred Users";
    private static final String UNREGISTREDUSERLABEL = "This is the UnRegistered User";
    private static Map<String, Integer> hourlyOffset = new HashMap<String, Integer>();
    private static Map<String, Integer> failureToCountMap = new HashMap<String, Integer>();

    private static final String emailSenderLocation = "C:/softtag/ProjectWorkspace/workspace_19aug/Report-Generation/resources/email-sender";
    private static final String EMAIL_NOTIFICATION_TEMPLATE_NAME = emailSenderLocation + "/email-downtime-notification-template.txt";
    private static final String vbsFileLocation = emailSenderLocation + "/Outbox/";
    private static String vbsTemplateFileLocation = emailSenderLocation + "/Email_Macro_Caller-Template.vbs";

    private static String CONFIG_FILE_NAME = "config/report_generation.properties";
    private static final String TEMP_DIR_LOCATION = System.getProperty("java.io.tmpdir", "./");

    private static Properties properties = null;
    private String templateData = "";
    private static String ToRecipients = "";
    private static String CCRecipients = "";
    private static String BCCRecipients = "";
    private static int sessionCount;

    public LogManagerDaoImpl() {
    }

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private FileUtility fileUtility;

    /************************************************ SERVICE COUNT GRAPH *********************************************************/
    @Override
    public DefaultCategoryDataset createServiceCountDataset() {

	Map<String, Integer> serviceToCountMap = new HashMap<String, Integer>();
	String Service = null;
	DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	List<TimeAudit> timeAudit = sessionFactory.getCurrentSession().createCriteria(TimeAudit.class).list();
	// List<Opcode_Service_Mapping> opcodeToServiceMap = getServiceList();
	List<OpcodeServiceMapping> opcodeToServiceMap = sessionFactory.getCurrentSession().createCriteria(OpcodeServiceMapping.class).list();

	List<TimeAudit> filterTimeAudit = getActivitiesFromLOG(timeAudit, opcodeToServiceMap);
	List<ServiceBreakup> bemBreakUp = sessionFactory.getCurrentSession().createCriteria(ServiceBreakup.class).list();
	Set<ServiceBreakup> serviceBreakupList = null;
	Map<String, String> map = new HashMap<String, String>();
	for (OpcodeServiceMapping i : opcodeToServiceMap)
	    map.put(i.getOPCODE(), i.getSERVICE());

	for (int i = 0; i < filterTimeAudit.size(); i++) {
	    // TimeAudit t = (TimeAudit) filterTimeAudit.get(i);

	    TimeAudit t = (TimeAudit) filterTimeAudit.get(i);

	    dataset.setValue(UNREGISTER_USER_CNT, SERVICE, UNREGISTREDUSERS);
	    if (map.get(t.getOpcode()) != null) {
		Service = map.get(t.getOpcode());
	    }
	    // --
	    serviceBreakupList = t.getServiceBreakupList();
	    for (Iterator iterator = serviceBreakupList.iterator(); iterator.hasNext();) {
		ServiceBreakup serviceBreakup = (ServiceBreakup) iterator.next();
		if (map.get(t.getOpcode()) != null) {
		    if ((t.getOpcode().equalsIgnoreCase("OP0603"))) {

			if (serviceBreakup.getCategoryId().equalsIgnoreCase("Telephone")) {
			    Service = "Airtime TopUp";
			} else if (serviceBreakup.getCategoryId().equalsIgnoreCase("MobileWallet")) {
			    Service = "MobileWallet";
			} else {
			    Service = "Utility Bill payment";
			}

		    } else {
			Service = map.get(t.getOpcode());
		    }

		}
	    }
	    // ---
	    if (t.getOpcode() == null)
		continue;
	    if (/* isValidDate(Integer.parseInt(t.getTime_Stamp())) && */(isRequest(t.getBusiness_ID()))) {
		serviceToCountMap = addDataToMap(serviceToCountMap, Service);
		dataset.setValue(serviceToCountMap.get(Service), SERVICE, Service);
	    }
	}

	return dataset;

    }

    /************************************************ HOURLY FREQUENCY GRAPH *********************************************************/
    @Override
    public DefaultCategoryDataset createHLFDataset() {
	Map<String, Integer> uniqueNumberLoginsPerHourMap = new HashMap<String, Integer>();
	Map<String, Integer> fullDayLogintoCountMap = new HashMap<String, Integer>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	List<String> mobileNumbersAndHours = new ArrayList<String>();
	List<String> mobileNumbers = new ArrayList<String>();

	List<TimeAudit> timeAudit = sessionFactory.getCurrentSession().createCriteria(TimeAudit.class).list();
	List<OpcodeServiceMapping> opcodeToServiceMap = sessionFactory.getCurrentSession().createCriteria(OpcodeServiceMapping.class).list();
	List<TimeAudit> filterTimeAudit = getActivitiesFromLOG(timeAudit, opcodeToServiceMap);

	for (int i = 0; i < filterTimeAudit.size(); i++) {
	    TimeAudit t = (TimeAudit) filterTimeAudit.get(i);
	    if (/* isValidDate(t.getTime_Stamp()) && */(isRequest(t.getBusiness_ID())) && t.getOpcode() != null) {

		if (t.getOpcode().equals("OP0109") || t.getOpcode().equals("OP0202")) {

		    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd hh:mm:ss.SSS");

		    java.util.Date date = null;
		    try {
			date = sdf.parse(t.getTime_Stamp());
		    } catch (ParseException e) {
			e.printStackTrace();
		    }
		    java.sql.Timestamp timestamp = new java.sql.Timestamp(date.getTime());
		    String hour = fetchHour(timestamp, t.getBusiness_ID());

		    String mobileNoAndHr = t.getMobile_Number() + hour;
		    if (!(mobileNumbersAndHours.contains(mobileNoAndHr))) {
			uniqueNumberLoginsPerHourMap = addDataToMap(uniqueNumberLoginsPerHourMap, hour);
			mobileNumbersAndHours.add(mobileNoAndHr);
		    }
		    System.out
			    .println("checking mobile Number " + t.getMobile_Number() + " Response:" + mobileNumbers.contains(t.getMobile_Number()));
		    if (!(mobileNumbers.contains(t.getMobile_Number()))) {
			fullDayLogintoCountMap = addDataToMap(fullDayLogintoCountMap, hour);
			mobileNumbers.add(t.getMobile_Number());
		    }
		}
	    }
	}

	for (Integer i = 100; i < 124; i++) {
	    String hour = i.toString();
	    hour = hour.substring(1);
	    dataset.setValue(uniqueNumberLoginsPerHourMap.get(hour), SERVICE, hour);
	}

	System.out.println("Full day active users login count: " + totalLoginCount(fullDayLogintoCountMap));
	return dataset;
    }

    /************************************************ TRANSACTION FAILURE GRAPH *********************************************************/
    @Override
    public DefaultCategoryDataset createServiceFailureCountDataset() {
	Map<String, Integer> serviceToFailureCountMap = new HashMap<String, Integer>();
	String Service = null;
	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	List<String> failureCodeList = new ArrayList<String>(5);

	failureCodeList.add("BEM08751");
	failureCodeList.add("BEM08744");
	failureCodeList.add("BEM08741");
	failureCodeList.add("BEM08729");
	failureCodeList.add("BEM08777");
	failureCodeList.add("BEM08650");
	failureCodeList.add("BEM08644");
	failureCodeList.add("BEM08875");
	failureCodeList.add("BEM08884");
	failureCodeList.add("BEM08610");
	failureCodeList.add("BEM08883");
	failureCodeList.add("BEM08882");
	failureCodeList.add("BEM08870");
	failureCodeList.add("BEM08890");
	failureCodeList.add("BEM08617");
	failureCodeList.add("BEM08876");
	failureCodeList.add("BEM08734");
	failureCodeList.add("BEM06696");
	failureCodeList.add("BEM07503");
	failureCodeList.add("BEM06754");
	failureCodeList.add("BEM08645");
	failureCodeList.add("BEM08886");
	failureCodeList.add("BEM08887");
	failureCodeList.add("BEM08648");
	failureCodeList.add("BEM06697");// biller alredy exist
	failureCodeList.add("BEM08888");// invalid recharge amount from selcom

	// for bill payment
	failureCodeList.add("BEM08733");// token threshhold reached
	failureCodeList.add("BEM08602");
	failureCodeList.add("BEM08875");
	failureCodeList.add("BEM08884");
	failureCodeList.add("BEM09027"); // invalid old pin erro

	failureCodeList.add("BEM09999");// bill pay

	List<TimeAudit> timeAudit = sessionFactory.getCurrentSession().createCriteria(TimeAudit.class).list();

	List<OpcodeServiceMapping> opcodeToServiceMap = sessionFactory.getCurrentSession().createCriteria(OpcodeServiceMapping.class).list();
	List<TimeAudit> filterTimeAudit = getActivitiesFromLOG(timeAudit, opcodeToServiceMap);

	Map<String, String> map = new HashMap<String, String>();
	for (OpcodeServiceMapping i : opcodeToServiceMap)
	    map.put(i.getOPCODE(), i.getSERVICE());

	for (int i = 0; i < filterTimeAudit.size(); i++) {
	    TimeAudit t = (TimeAudit) filterTimeAudit.get(i);

	    if (map.get(t.getOpcode()) != null) {
		Service = map.get(t.getOpcode());
	    }

	    if (/* isValidDate(t.getTimeStamp()) && */(isRequest(t.getBusiness_ID())) /* && !(pPcode.contains(activity.getPpErrorCode())) */) {

		if (t.getResponse().equals("ERROR") || t.getResponse().equals("FAILURE")) {
		    if (!(Service.equalsIgnoreCase("Application Accessed")) && !failureCodeList.contains(t.getRespose_Code())
		    /* && (t.getFailure() != null) */) {

			serviceToFailureCountMap = addDataToMap(serviceToFailureCountMap, Service);
			dataset.setValue(serviceToFailureCountMap.get(Service), SERVICE, Service);
		    }
		}

	    }

	}

	return dataset;
    }

    /************************************************ SHM PERFORMANCE GRAPH *********************************************************/
    @Override
    public DefaultCategoryDataset createPerformanceCountDataset(Map<String, Double> averageMap) {
	Map<String, List<Double>> serviceToResponseTimesMap = new HashMap<String, List<Double>>();
	String Service = null;
	// Map<String, List<Double>> serviceUserRespTimesMap = new HashMap<String, List<Double>>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	List<TimeAudit> timeAudit = sessionFactory.getCurrentSession().createCriteria(TimeAudit.class).list();

	List<OpcodeServiceMapping> opcodeToServiceMap = sessionFactory.getCurrentSession().createCriteria(OpcodeServiceMapping.class).list();
	List<TimeAudit> filterTimeAudit = getActivitiesFromLOG(timeAudit, opcodeToServiceMap);

	Map<String, String> map = new HashMap<String, String>();
	for (OpcodeServiceMapping i : opcodeToServiceMap)
	    map.put(i.getOPCODE(), i.getSERVICE());

	for (int i = 0; i < filterTimeAudit.size(); i++) {
	    TimeAudit t = (TimeAudit) filterTimeAudit.get(i);

	    if (map.get(t.getOpcode()) != null) {
		Service = map.get(t.getOpcode());
	    }

	    if (/* isValidDate(activity.getTimeStamp()) && */(isRequest(t.getBusiness_ID()))) {

		if (t.getResponse().equals("SUCCESS")) {
		    double respTime = Double.parseDouble(t.getSHM_Response_Time());
		    serviceToResponseTimesMap = addResponseTimetoService(serviceToResponseTimesMap, Service, respTime);
		    List<Double> responseTimes = serviceToResponseTimesMap.get(Service);
		    Double averageResponseTime = getAverageFromList(responseTimes);

		    Double ninetyPerc = getNinetyPerc(responseTimes);
		    Double tenPerc = getTenPerc(responseTimes);

		    dataset.setValue(tenPerc, "Min", Service);
		    dataset.setValue(averageResponseTime, "Average", Service);
		    dataset.setValue(ninetyPerc, "Max", Service);

		}
	    }
	}

	return dataset;
    }

    /************************************************ USER RESPONSE GRAPH *********************************************************/
    @Override
    public DefaultCategoryDataset createUserPerformanceCountDataset() {
	Map<String, List<Double>> serviceToResponseTimesMap = new HashMap<String, List<Double>>();
	String Service = null;

	DefaultCategoryDataset userDataset = new DefaultCategoryDataset();

	List<TimeAudit> timeAudit = sessionFactory.getCurrentSession().createCriteria(TimeAudit.class).list();

	List<OpcodeServiceMapping> opcodeToServiceMap = sessionFactory.getCurrentSession().createCriteria(OpcodeServiceMapping.class).list();
	List<TimeAudit> filterTimeAudit = getActivitiesFromLOG(timeAudit, opcodeToServiceMap);

	Map<String, String> map = new HashMap<String, String>();
	for (OpcodeServiceMapping i : opcodeToServiceMap)
	    map.put(i.getOPCODE(), i.getSERVICE());

	for (int i = 0; i < filterTimeAudit.size(); i++) {
	    TimeAudit t = (TimeAudit) filterTimeAudit.get(i);

	    if (map.get(t.getOpcode()) != null) {
		Service = map.get(t.getOpcode());
	    }

	    if (/* isValidDate(activity.getTimeStamp()) && */(isRequest(t.getBusiness_ID()))) {

		if (t.getResponse().equals("SUCCESS")) {
		    double respTime = Double.parseDouble(t.getSHM_Response_Time());
		    serviceToResponseTimesMap = addUserResponseTimetoService(serviceToResponseTimesMap, Service, respTime);
		}
	    }

	}

	Set<String> ServiceNameSet = serviceToResponseTimesMap.keySet();
	System.out.println("***Service responce map" + serviceToResponseTimesMap);
	for (String ServiceName : ServiceNameSet) {
	    int userMinCount = 0;
	    int userAvgCount = 0;
	    int userMaxCount = 0;

	    List<Double> responseTimes = serviceToResponseTimesMap.get(ServiceName);

	    for (Double value : responseTimes) {
		if (value >= 0 && value <= 1) {
		    userMinCount++;

		} else if (value > 1 && value <= 5) {
		    userAvgCount++;

		} else if (value > 5) {
		    userMaxCount++;

		}
	    }

	    userDataset.setValue(userMinCount, "Min[0-1 ms]", ServiceName);
	    userDataset.setValue(userAvgCount, "Average[1-5 ms]", ServiceName);
	    userDataset.setValue(userMaxCount, "Max[>5 ms]", ServiceName);

	}

	return userDataset;
    }

    /************************************************ PIE CHART ********************************************************************/
    @Override
    public DefaultPieDataset createServiceFailureDataset() {

	Map<String, String> sourceerror = new HashMap<String, String>();
	String Service = null;
	List<TimeAudit> activityset = new ArrayList<TimeAudit>();
	List<TimeAudit> activitylist = new ArrayList<TimeAudit>();
	DefaultPieDataset dataset = new DefaultPieDataset();
	StringBuilder serviceData = new StringBuilder();
	StringBuilder hostData = new StringBuilder();
	Map<String, List<String>> multimap = new HashMap<String, List<String>>();
	List<String> sHMCodeList = new ArrayList<String>(5);

	sHMCodeList.add("BEM08000");
	// sHMCodeList.add("BEM08751");
	// sHMCodeList.add("BEM08744");
	// sHMCodeList.add("BEM08729");
	// sHMCodeList.add("BEM08777");
	// sHMCodeList.add("BEM08741");

	serviceData.append("Service Name").append(",").append("Host").append(",").append("Error Count").append(",").append("PP Error Code").append(
		",").append("PP Error Msg").append("\n");

	hostData.append("MobileNo").append(",").append("Country").append(",").append("TimeStamp").append(",").append("SessionId").append(",").append(
		"BEM ErrorCode").append(",").append("Cust Ref Id").append(",").append("Service Name").append(",").append("Host").append(",").append(
		"PP Error Code").append(",").append("PP Error Msg").append("\n");

	List<TimeAudit> timeAudit = sessionFactory.getCurrentSession().createCriteria(TimeAudit.class).list();
	// List<ServiceBreakup> bemBreakUp = sessionFactory.getCurrentSession().createCriteria(ServiceBreakup.class).list();

	List<OpcodeServiceMapping> opcodeToServiceMap = sessionFactory.getCurrentSession().createCriteria(OpcodeServiceMapping.class).list();
	List<TimeAudit> filterTimeAudit = getActivitiesFromLOG(timeAudit, opcodeToServiceMap);

	Map<String, String> map = new HashMap<String, String>();

	Set<ServiceBreakup> serviceBreakupList = null;
	for (OpcodeServiceMapping i : opcodeToServiceMap)
	    map.put(i.getOPCODE(), i.getSERVICE());

	for (int i = 0; i < filterTimeAudit.size(); i++) {

	    TimeAudit t = (TimeAudit) filterTimeAudit.get(i);

	    System.out.println("* time Audit tranID " + t.getTransaction_ID());
	    serviceBreakupList = t.getServiceBreakupList();

	    /*
	     * for (Iterator iterator = serviceBreakupList.iterator(); iterator.hasNext();) { ServiceBreakup serviceBreakup = (ServiceBreakup)
	     * iterator.next(); System.out.println(" * serviceBreakuptranID " + serviceBreakup.getTransaction_ID());
	     *
	     * }
	     */

	    if (map.get(t.getOpcode()) != null) {
		Service = map.get(t.getOpcode());
	    }
	    if (t.getServiceBreakupList() != null) {
		String Source = null;
		for (Iterator iterator = serviceBreakupList.iterator(); iterator.hasNext();) {
		    ServiceBreakup serviceBreakup = (ServiceBreakup) iterator.next();
		    if ((serviceBreakup.getHost() != null) /* && (isValidDate(activity.getTimeStamp())) */&& (isRequest(t.getBusiness_ID()))/*
																	     * &&
																	     * !(pPcode
																	     * .
																	     * contains
																	     * (
																	     * activity
																	     * .
																	     * getPpErrorCode
																	     * ()))
																	     */) {
			if (serviceBreakup.getResponse().equalsIgnoreCase("ERROR") || serviceBreakup.getResponse().equalsIgnoreCase("FAILURE")) {

			    if (serviceBreakup.getHost() != null)
				Source = serviceBreakup.getHost();
			    else {
				Source = "SHM";
			    }

			}
			if (!(Service.equals("Verify User")) && !sHMCodeList.contains(t.getRespose_Code())) {

			    failureToCountMap = addFailureToMap(failureToCountMap, Source);

			    // activityset.add(activity);

			}
		    }
		}

	    }
	}
	// Iterate over Map

	for (String failureKey : failureToCountMap.keySet()) {
	    int failureCnt = failureToCountMap.get(failureKey);
	    // create dataset using map
	    dataset.setValue(failureKey + "=" + failureCnt, failureCnt);
	}

	// }
	/*
	 * for (Activity acct : activityset) {
	 *
	 * if (sourceerror.get(acct.getFailure()) != null) { if (!(sourceerror.get(acct.getFailure()).equals(acct.getPpErrorCode()))) {
	 * sourceerror.put(acct.getFailure(), acct.getPpErrorCode());
	 *
	 * if (acct.getFailure().equalsIgnoreCase("shm")) { acct.setPpErrorCode(null); acct.setPpErrorDesc(null); acct.setURN(null); } // error
	 * summary serviceData.append(acct.getService()).append(",").append(acct.getFailure()).append(",").append(
	 *
	 * failureToCountMap.get(acct.getFailure())).append(",").append(acct.getPpErrorCode()).append(",").append(acct.getPpErrorDesc());
	 * serviceData.append("\n"); FileUtility.writeToFile("ERROR_Summary.csv", serviceData.toString(), false);
	 *
	 * // host error logs.csv
	 * hostData.append(acct.getURN()).append("||").append(acct.getService()).append("||").append(acct.getFailure()).append("||").append(
	 * failureToCountMap.get(acct.getFailure())).append("||").append(acct.getPpErrorCode()).append("||").append( acct.getPpErrorDesc());
	 * hostData.append("\n"); FileUtility.writeToFile("Host_Error_Log.csv", hostData.toString(), false);
	 *
	 * } } else { sourceerror.put(acct.getFailure(), acct.getPpErrorCode()); if (acct.getFailure().equalsIgnoreCase("shm")) {
	 * acct.setPpErrorCode(null); acct.setPpErrorDesc(null); acct.setURN(null); }
	 *
	 * serviceData.append(acct.getService()).append(",").append(acct.getFailure()).append(",").append(
	 * failureToCountMap.get(acct.getFailure())).append(",").append(acct.getPpErrorCode()).append(",").append(acct.getPpErrorDesc());
	 * serviceData.append("\n"); FileUtility.writeToFile("ERROR_Summary.csv", serviceData.toString(), false); // host error logs.csv
	 *
	 * hostData.append(acct.getURN()).append("||").append(acct.getService()).append("||").append(acct.getFailure()).append("||").append(
	 * failureToCountMap.get(acct.getFailure())).append("||").append(acct.getPpErrorCode()).append("||").append( acct.getPpErrorDesc());
	 * hostData.append("\n"); FileUtility.writeToFile("Host_Error_Log.csv", hostData.toString(), false);
	 *
	 * }
	 *
	 * }
	 */

	return dataset;

    }

    /************************************************ BEM PERFORMANCE GRAPH *********************************************************/
    @Override
    public DefaultCategoryDataset createBPerformanceCountDataset() {

	Map<String, List<Double>> serviceToResponseTimesMap = new HashMap<String, List<Double>>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	List<ServiceBreakup> bemBreakUp = sessionFactory.getCurrentSession().createCriteria(ServiceBreakup.class).list();

	for (int i = 0; i < bemBreakUp.size(); i++) {

	    ServiceBreakup breakup = (ServiceBreakup) bemBreakUp.get(i);

	    if (isNotServiceFault(breakup.getServiceId()) /* && isValidDate(breakup.getTimeStamp()) */) {

		if (breakup.getResponse().equals("Success")) {

		    double respTime = Double.parseDouble(breakup.getService_Time());
		    serviceToResponseTimesMap = addResponseTimetoService(serviceToResponseTimesMap, breakup.getServiceId(), respTime);
		    List<Double> responseTimes = serviceToResponseTimesMap.get(breakup.getServiceId());
		    Double averageResponseTime = getAverageFromList(responseTimes);

		    Double ninetyPerc = getNinetyPerc(responseTimes);
		    Double tenPerc = getTenPerc(responseTimes);

		    dataset.setValue(tenPerc, "Min", breakup.getServiceId());
		    dataset.setValue(averageResponseTime, "Average", breakup.getServiceId());
		    dataset.setValue(ninetyPerc, "Max", breakup.getServiceId());

		}
	    }
	}

	return dataset;

    }

    /************************************************* COMMON METHODS ****************************************************************/
    private static boolean isNotServiceFault(String service) {

	return !("serviceFault".equals(service));
    }

    private static Map<String, Integer> addFailureToMap(Map<String, Integer> graphData, String failurename) {

	int failureCount;
	if (graphData.get(failurename) != null) {
	    failureCount = graphData.get(failurename);
	    failureCount++;
	} else {
	    failureCount = 1;

	}
	graphData.put(failurename, failureCount);
	return graphData;
    }

    private static Map<String, List<Double>> addUserResponseTimetoService(Map<String, List<Double>> graphData, String serviceName, double d) {

	List<Double> responseTimes = new ArrayList<Double>();
	if (graphData.get(serviceName) != null) {
	    responseTimes = graphData.get(serviceName);
	}
	responseTimes.add((double) (d / 1000));
	graphData.put(serviceName, responseTimes);
	return graphData;
    }

    private static Double getNinetyPerc(List<Double> responseTimes) {
	Collections.sort(responseTimes);
	int length = responseTimes.size();
	int ninetieth = (int) (length * 0.9);
	Double nineth = responseTimes.get(ninetieth);
	return (double) Math.round(nineth * 10) / 10;

    }

    private static Double getTenPerc(List<Double> responseTimes) {
	Collections.sort(responseTimes);
	int length = responseTimes.size();
	int ninetieth = (int) (length * 0.1);
	Double nineth = responseTimes.get(ninetieth);
	return (double) Math.round(nineth * 10) / 10;

    }

    private static Map<String, List<Double>> addResponseTimetoService(Map<String, List<Double>> graphData, String serviceName, double d) {

	List<Double> responseTimes = new ArrayList<Double>();
	if (graphData.get(serviceName) != null) {
	    responseTimes = graphData.get(serviceName);
	}
	responseTimes.add((double) (d / 1000));
	graphData.put(serviceName, responseTimes);
	return graphData;
    }

    private static Double getAverageFromList(List<Double> responseTimes) {

	Double sum = 0.0;
	for (int i = 0; i < responseTimes.size(); i++) {

	    sum += responseTimes.get(i);
	}
	Double avg = (sum / responseTimes.size());

	return (double) Math.round(avg * 10) / 10;
    }

    public List<TimeAudit> getActivitiesFromLOG(List<TimeAudit> timeAudit, List<OpcodeServiceMapping> opcodeToServiceMap) {

	/*
	 * for (TimeAudit activity : timeAudit) { if (activity.isUnRegisterUser() && (isRequest(activity.getBusinessId()))) { UNREGISTER_USER_CNT++; }
	 * }
	 */
	return filterActivities(timeAudit, opcodeToServiceMap);
	// return activities;
    }

    public List<TimeAudit> filterActivities(List<TimeAudit> activities, List<OpcodeServiceMapping> opcodeToServiceMap) {
	// List<OpcodeServiceMapping> opcodeToServiceMap = sessionFactory.getCurrentSession().createCriteria(OpcodeServiceMapping.class).list();
	Map<String, String> map = new HashMap<String, String>();
	for (OpcodeServiceMapping i : opcodeToServiceMap)
	    map.put(i.getOPCODE(), i.getSERVICE());

	for (int i = 0; i < activities.size(); i++) {
	    TimeAudit t = (TimeAudit) activities.get(i);
	    if (t.getOpcode() != null && t.getOpcode().equalsIgnoreCase("This i")) {
	    	UNREGISTER_USER_CNT++;
	    }
	    if (map.get(t.getOpcode()) == null) {
	    	activities.remove(activities.get(i--));
	    }
	}

	System.out.println("Final list of activities");

	for (TimeAudit activity : activities)
	    System.out.println(activity.getOpcode());

	return activities;

    }

    private static String fetchHour(Date inputDate, String country) {

	hourlyOffset.put("TZBRB", 3);
	hourlyOffset.put("UGBRB", 3);
	hourlyOffset.put("KEBRB", 3);
	hourlyOffset.put("GHBRB", 0);
	DateFormat writeFormat = new SimpleDateFormat("HH");
	System.out.println(country);
	inputDate = DateUtils.addHours(inputDate, hourlyOffset.get(country));
	String formattedDate = "";
	if (inputDate != null) {
	    formattedDate = writeFormat.format(inputDate);
	}
	return formattedDate;
    }

    private static int totalLoginCount(Map<String, Integer> graphData) {

	Integer loginTotal = 0;
	for (Integer value : graphData.values()) {
	    loginTotal = loginTotal + value; // Can also be done by total += value;
	}

	return loginTotal;

    }

    private static Map<String, Integer> addDataToMap(Map<String, Integer> graphData, String serviceName) {

	int serviceCount;
	if (graphData.get(serviceName) != null) {
	    serviceCount = graphData.get(serviceName);
	    serviceCount++;

	} else {
	    serviceCount = 1;

	}
	graphData.put(serviceName, serviceCount);

	return graphData;
    }

    private static boolean isRequest(String businessId) {

	if (!businessId.equalsIgnoreCase("TZBRB")) {

	    return false;
	}

	return true;
    }

    private static boolean isValidDate(Date inputDate) {

	/*
	 * Date yesterday = DateUtils.addDays(new Date(), -1); DateFormat onlyDate = new SimpleDateFormat("yyyy-MMM-dd"); String yesterdayFormatted =
	 * onlyDate.format(yesterday);
	 *
	 * String inputFormatted = onlyDate.format(inputDate);
	 *
	 * if (!(inputFormatted.equals(yesterdayFormatted))) { return false; }
	 */

	return true;
    }

    @Override
    public String sendEmailCall() {

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	Calendar cal = GregorianCalendar.getInstance();
	String today = dateFormat.format(cal.getTime());
	String subject = " [SECURE] SHM TZ PROD | Services response reports";
	System.out.println("Creating Email Notification script file - " + EMAIL_NOTIFICATION_TEMPLATE_NAME);
	String bodyText = fileUtility.readContents1(EMAIL_NOTIFICATION_TEMPLATE_NAME);
	int sessionCount = 0;
	List<TimeAudit> timeAudit = sessionFactory.getCurrentSession().createCriteria(TimeAudit.class).list();
	for (int i = 0; i < timeAudit.size(); i++) {
	    TimeAudit t = (TimeAudit) timeAudit.get(i);
	    if (((t.getOpcode()) != null) && (t.getOpcode().equalsIgnoreCase("OP0214"))) {
		sessionCount++;
	    }
	}
	// SESSION ;
	// SELF_REG_COUNT ;
	// REG_USER_COUNT ;
	bodyText = bodyText.replaceAll(DATE, today);
	bodyText = bodyText.replaceAll(SESSION, String.valueOf(sessionCount));
	String AttachmentName = TEMP_DIR_LOCATION + "Feature_Response_Column_Chart.jpg";

	String vbsFileName = vbsFileLocation + "Email-Notification-" + System.currentTimeMillis() + ".vbs";
	System.out.println("Creating Email Notification script file - " + vbsFileName);

	FileInputStream fileInputStream = null;
	properties = new Properties();
	ToRecipients = "Jayashree.Khomane@barclayscorp.com";
	CCRecipients = "Jayashree.Khomane@barclayscorp.com";

	try {
	    InputStream inputStreamtemplate = new FileInputStream(vbsTemplateFileLocation);
	    templateData = IOUtils.toString(inputStreamtemplate);
	    // fileInputStream = new FileInputStream(CONFIG_FILE_NAME);
	    // properties.load(fileInputStream);
	    // String ToRecipients = properties.getProperty("TO_TEAM");
	    // String CCRecipients = properties.getProperty("CC_TEAM");
	    // String BCCRecipients = properties.getProperty("BCC_TEAM");

	    ToRecipients = "Jayashree.Khomane@barclayscorp.com";
	    CCRecipients = "Jayashree.Khomane@barclayscorp.com";
	    // String BCCRecipients = properties.getProperty("BCC_TEAM");

	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	} catch (IOException e) {
	    e.printStackTrace();
	}
	String importence = "High";
	String sendEmailCall = null;
	try {

	    sendEmailCall = "xlApp.Run \"SendMail\", \"" + ToRecipients + "\", \"" + CCRecipients + "\", \"" + BCCRecipients + "\", \"" + subject
		    + today + "\",  \"" + "CStr(" + URLEncoder.encode(bodyText, "UTF-8") + ")" + "\", \"" + importence + "\", \"" + AttachmentName
		    + "\"";

	} catch (UnsupportedEncodingException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

	System.out.println("Update Email script - Add [" + sendEmailCall + "]");

	String data = templateData.replace("'SEND_EMAIL_CALL", sendEmailCall);
	File vbsFile = new File(vbsFileName);

	System.out.println("Creating Email Notification script file getAbsolutePath - " + vbsFile.getAbsolutePath());

	FileUtility.writeToFile(vbsFile.getAbsolutePath(), data, false);
	return null;
    }
}
