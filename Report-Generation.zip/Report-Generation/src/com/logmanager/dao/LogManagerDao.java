package com.logmanager.dao;

import java.util.Map;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public interface LogManagerDao {

    public DefaultCategoryDataset createServiceCountDataset();

    public DefaultCategoryDataset createHLFDataset();

    public DefaultCategoryDataset createServiceFailureCountDataset();

    public DefaultCategoryDataset createPerformanceCountDataset(Map<String, Double> averageMap);

    public DefaultCategoryDataset createUserPerformanceCountDataset();

    public DefaultPieDataset createServiceFailureDataset();

    public DefaultCategoryDataset createBPerformanceCountDataset();

    public String sendEmailCall();
}
