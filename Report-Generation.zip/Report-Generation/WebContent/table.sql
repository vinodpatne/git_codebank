use LOG_MANAGEMENT_DB;

drop table	TIME_AUDIT;
 CREATE TABLE TIME_AUDIT (
		  Transaction_ID VARCHAR(50) NOT NULL PRIMARY KEY,
          Time_Stamp VARCHAR(50),
		  Session_Id VARCHAR(50),
		  Business_ID VARCHAR(5),
		  Mobile_Number VARCHAR(50),
		  Opcode VARCHAR(6),
		  Response VARCHAR(50),
		  Respose_Code VARCHAR(30),
		  SHM_Response_Time VARCHAR(6),
		  BEM_Response_Time VARCHAR(6)
		);

drop table BEM_SERVICE_BREAKUP;
 CREATE TABLE BEM_SERVICE_BREAKUP(
 		 ID INT NOT NULL,
		 Transaction_ID VARCHAR(50) NOT NULL,
		 Time_Stamp VARCHAR(50),
		 ServiceId VARCHAR(50),
		 ConsumerRefNo VARCHAR(50),
		 CategoryId VARCHAR(50),
		 Response VARCHAR(50),
		 Service_Time VARCHAR(50),
		 BemError VARCHAR(50),
		 Host VARCHAR(50),
		 PP_Error_Code VARCHAR(50),
		 PP_Error_Desc VARCHAR(50),
		INDEX (Transaction_ID),
        FOREIGN KEY (Transaction_ID)  REFERENCES TIME_AUDIT(Transaction_ID)  ON DELETE CASCADE

 );

 drop table Opcode_Service_Mapping;
CREATE TABLE Opcode_Service_Mapping(
OPCODE VARCHAR(50) NOT NULL,
SERVICE VARCHAR(50)
);



Transaction_ID,Time_Stamp,Session_Id,Business_ID,Mobile_Number,Opcode,Response,Respose_Code,SHM_Response_Time,BEM_Response_Time
Transaction_ID,Time_Stamp,Break_Up


select * from BEM_SERVICE_BREAKUP;