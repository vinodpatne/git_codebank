package com.barclays.bmg.pojo;

import java.util.List;

public class EmailMessage {

    String toRecipients;
    String ccRecipients;
    String bccRecipients;
    String system;
    String importance;
    List<String> fileAttachment;
    String subject;

    public EmailMessage(String toRecipients, String ccRecipients, String bccRecipients, List<String> fileAttachment, String subject) {
	super();
	this.toRecipients = toRecipients;
	this.ccRecipients = ccRecipients;
	this.bccRecipients = bccRecipients;
	this.fileAttachment = fileAttachment;
	this.subject = subject;
    }

    public String getSubject() {
	return subject;
    }

    public void setSubject(String subject) {
	this.subject = subject;
    }

    /**
     * @return the toRecipients
     */
    public final String getToRecipients() {
	return toRecipients;
    }

    public EmailMessage() {
	super();
    }

    /**
     * @param toRecipients
     *            the toRecipients to set
     */
    public final void setToRecipients(String toRecipients) {
	this.toRecipients = toRecipients;
    }

    /**
     * @return the ccRecipients
     */
    public final String getCcRecipients() {
	return ccRecipients;
    }

    /**
     * @param ccRecipients
     *            the ccRecipients to set
     */
    public final void setCcRecipients(String ccRecipients) {
	this.ccRecipients = ccRecipients;
    }

    /**
     * @return the bccRecipients
     */
    public final String getBccRecipients() {
	return bccRecipients;
    }

    /**
     * @param bccRecipients
     *            the bccRecipients to set
     */
    public final void setBccRecipients(String bccRecipients) {
	this.bccRecipients = bccRecipients;
    }

    /**
     * @return the system
     */
    public final String getSystem() {
	return system;
    }

    /**
     * @param system
     *            the subject to set
     */
    public final void setSystem(String system) {
	this.system = system;
    }

    /**
     * @return the importance
     */
    public final String getImportance() {
	return importance;
    }

    /**
     * @param importance
     *            the importance to set
     */
    public final void setImportance(String importance) {
	this.importance = importance;
    }

    /**
     * @return the fileAttachment1
     */
    public final List<String> getFileAttachment() {
	return fileAttachment;
    }

    /**
     * @param fileAttachment1
     *            the fileAttachment1 to set
     */
    public final void setFileAttachment(List<String> fileAttachment) {
	this.fileAttachment = fileAttachment;
    }

}
