package com.barclays.bmg.pojo;

import java.util.List;
import java.util.Map;

public class ShmService {
    private String name;
    private List<String> bEMServicesCalled;
    private double timeTaken;
    private double bEmTimeTaken;
    private double sHMTimeTaken;
    private static Map<String, Double> bEMAverageMap;
    private double sHMTimerPerc;
    private double bEMTimePerc;
    public String getName() {
	return name;
    }
    public void setName(String name) {
	this.name = name;
    }
    public List<String> getbEMServicesCalled() {
	return bEMServicesCalled;
    }
    public void setbEMServicesCalled(List<String> bEMServicesCalled) {

	this.bEMServicesCalled = bEMServicesCalled;

	for(String bEMServiceName: bEMServicesCalled)
	{
	    if(!(bEMServiceName.trim().equals("")))
	    {
		double BEMserviceTimeTaken=0;
		System.out.println(bEMAverageMap.values());
		System.out.println(bEMAverageMap.keySet());
		System.out.println(bEMServiceName);
		if(bEMAverageMap.get(bEMServiceName.trim())!=null)
		{
		    System.out.println("Not null");
		    BEMserviceTimeTaken = bEMAverageMap.get(bEMServiceName);
		}
		
		   	
		setbEmTimeTaken(bEmTimeTaken+BEMserviceTimeTaken);
	    }
	}

    }
    public double getTimeTaken() {
	return timeTaken;
    }
    public void setTimeTaken(double timeTaken) {
	this.timeTaken = timeTaken;
    }
    public double getbEmTimeTaken() {
	return bEmTimeTaken;
    }
    public void setbEmTimeTaken(double bEmTimeTaken) {
	this.bEmTimeTaken = bEmTimeTaken;
	if(timeTaken>0)
	sHMTimeTaken = timeTaken-bEmTimeTaken;
	else
	    this.bEmTimeTaken=0;
	if(timeTaken>0)
	{
	bEMTimePerc = this.bEmTimeTaken*100/timeTaken;
	sHMTimerPerc = sHMTimeTaken*100/timeTaken;
	}
    }
    public double getsHMTimeTaken() {
	return sHMTimeTaken;
    }
    public void setsHMTimeTaken(double sHMTimeTaken) {
	this.sHMTimeTaken = sHMTimeTaken;
    }
    public static Map<String, Double> getbEMAverageMap() {
	return bEMAverageMap;
    }
    public static void setbEMAverageMap(Map<String, Double> bEMAverageMap) {
	ShmService.bEMAverageMap = bEMAverageMap;
    }
    @Override
    public String toString() {
	return "ShmService [name=" + name + ", bEMServicesCalled=" + bEMServicesCalled + ", timeTaken=" + timeTaken + ", bEmTimeTaken="
		+ bEmTimeTaken + ", sHMTimeTaken=" + sHMTimeTaken + "]";
    }
    public double getsHMTimerPerc() {
	return sHMTimerPerc;
    }
    public void setsHMTimerPerc(double sHMTimerPerc) {
	this.sHMTimerPerc = sHMTimerPerc;
    }
    public double getbEMTimePerc() {
	return bEMTimePerc;
    }
    public void setbEMTimePerc(double bEMTimePerc) {
	this.bEMTimePerc = bEMTimePerc;
    }
   


}
