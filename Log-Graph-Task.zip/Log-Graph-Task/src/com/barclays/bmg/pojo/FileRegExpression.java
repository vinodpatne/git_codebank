package com.barclays.bmg.pojo;

public class FileRegExpression {
    String bemtatcsv;

}
