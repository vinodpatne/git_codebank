package com.barclays.bmg.pojo;

import java.util.Date;

public class Activity {
    private Date timeStamp;
    private String ppErrorCode;
    private String service;
    private String serviceName;
    private String failure;
    private String response;
    private String country;
    private String mobileNo;
    private double responseTime;
    private String opCode;
    private String businessId;
    private String session;
    private String responseCode;
    private String PpErrorDesc;
    private String uRN;
    private String bemErrorCode;
    private String sessionId;

    public String getBemErrorCode() {
	return bemErrorCode;
    }

    public void setBemErrorCode(String bemErrorCode) {
	this.bemErrorCode = bemErrorCode;
    }

    public String getSessionId() {
	return sessionId;
    }

    public void setSessionId(String sessionId) {
	this.sessionId = sessionId;
    }

    public String getBusinessId() {
	return businessId;
    }

    public void setBusinessId(String businessId) {
	this.businessId = businessId;
    }

    public String getURN() {
	return uRN;
    }

    public void setURN(String urn) {
	uRN = urn;
    }

    private boolean isUnRegisterUser;

    public String getPpErrorDesc() {
	return PpErrorDesc;
    }

    public void setPpErrorDesc(String ppErrorDesc) {
	PpErrorDesc = ppErrorDesc;
    }

    public String getServiceName() {
	return serviceName;
    }

    public void setServiceName(String serviceName) {
	this.serviceName = serviceName;
    }

    public String getFailure() {
	return failure;
    }

    public void setFailure(String failure) {
	this.failure = failure;
    }

    public boolean isUnRegisterUser() {
	return isUnRegisterUser;
    }

    public void setUnRegisterUser(boolean isUnRegisterUser) {
	this.isUnRegisterUser = isUnRegisterUser;
    }

    public Date getTimeStamp() {
	return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
	this.timeStamp = timeStamp;
    }

    public String getService() {
	return service;
    }

    public void setService(String service) {
	this.service = service;
    }

    public String getResponse() {
	return response;
    }

    public void setResponse(String response) {
	this.response = response;
    }

    public double getResponseTime() {
	return responseTime;
    }

    public void setResponseTime(double responseTime) {
	this.responseTime = responseTime;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public String getMobileNo() {
	return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
    }

    public String getOpCode() {
	return opCode;
    }

    @Override
    public String toString() {
	return "Activity [timeStamp=" + timeStamp + ", service=" + service + ", response=" + response + ", country=" + country + ", mobileNo="
		+ mobileNo + ", responseTime=" + responseTime + ", opCode=" + opCode + ",failure=" + failure + "]";
    }

    public void setOpCode(String opCode) {
	this.opCode = opCode;
    }

    public String getSession() {
	return session;
    }

    public void setSession(String session) {
	this.session = session;
	this.country = session.substring(session.indexOf("BRB") - 2, session.indexOf("BRB"));
	try {
	    this.mobileNo = session.substring(session.indexOf("BRB") + 4, session.indexOf("BRB") + 16);
	} catch (StringIndexOutOfBoundsException e) {
	    this.mobileNo = session.substring(session.indexOf("BRB") + 4, session.indexOf("BRB") + 13);
	}
    }

    public String getResponseCode() {
	return responseCode;
    }

    public void setResponseCode(String responseCode) {
	this.responseCode = responseCode;
    }

    public String getPpErrorCode() {
	return ppErrorCode;
    }

    public void setPpErrorCode(String ppErrorCode) {
	this.ppErrorCode = ppErrorCode;
    }

}
