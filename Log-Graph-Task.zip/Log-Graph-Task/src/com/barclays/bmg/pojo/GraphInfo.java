package com.barclays.bmg.pojo;

public class GraphInfo {

}
