package com.barclays.bmg.pojo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.io.IOUtils;

public class FileUtility {

    public static StringBuffer readContents(String fileName) {
	String fileContents = null;
	StringBuffer br = null;
	InputStream inputStream = null;
	File file = new File(fileName);
	if (file.exists()) {

	    try {
		inputStream = new FileInputStream(fileName);
		fileContents = IOUtils.toString(inputStream);
		br = new StringBuffer(fileContents);
		;
	    } catch (Exception e) {

	    } finally {
		if (inputStream != null) {
		    try {
			inputStream.close();
		    } catch (IOException e) {

		    }
		}
	    }
	} else {

	}
	return br;
    }

    public static void writeToFile(String fileName, String data, boolean append) {
	OutputStream outputStream = null;
	try {
	    outputStream = new FileOutputStream(fileName, append);
	    IOUtils.write(data, outputStream);
	} catch (Exception e) {

	} finally {
	    if (outputStream != null) {
		try {
		    outputStream.close();
		} catch (IOException e) {

		}
	    }
	}
    }

    public static BufferedReader getBufferReader(String csvFile) throws FileNotFoundException {
	BufferedReader br;
	URLConnection connection = null;
	InputStream inStream = null;

	try {
	    URL url = new URL(csvFile);

	    connection = url.openConnection();

	    connection.setDoInput(true);
	    inStream = connection.getInputStream();
	    br = new BufferedReader(new InputStreamReader(inStream));
	    return br;
	} catch (Exception e) {
	    br = new BufferedReader(new FileReader(csvFile));
	    return br;
	}

    }

}
