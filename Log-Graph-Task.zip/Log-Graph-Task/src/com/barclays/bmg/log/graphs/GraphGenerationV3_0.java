package com.barclays.bmg.log.graphs;

import java.io.BufferedReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.barclays.bmg.pojo.FileUtility;
import com.barclays.bmg.pojo.ShmService;

public class GraphGenerationV3_0 {

    private static String COMMA_SEPARATOR = ",";
    private static List<ShmService> shmServices = new ArrayList<ShmService>();

    public static void main(String[] args) throws IOException, ParseException {

	BEM_GraphGeneration.main(null);
	SHM_TimeAuditGraphs.main(null);

	ShmService.setbEMAverageMap(BEM_GraphGeneration.averageMap);

	prepareListOfServices();
	prepareCSVFile();

    }

    private static void prepareCSVFile() {
	StringBuilder sb = new StringBuilder();
	sb.append("ServiceName,Total Time Taken,BEM service time taken, BEM Perc, SHM Time taken, SHM Perc\n");
	for (ShmService service : shmServices) {
	    sb.append(service.getName() + COMMA_SEPARATOR + service.getTimeTaken() + COMMA_SEPARATOR + service.getbEmTimeTaken() + COMMA_SEPARATOR
		    + service.getbEMTimePerc() + COMMA_SEPARATOR + service.getsHMTimeTaken() + COMMA_SEPARATOR + service.getsHMTimerPerc() + "\n");
	}
	FileUtility.writeToFile("MAP Result.csv", sb.toString(), false);
    }

    private static void prepareListOfServices() throws IOException {

	BufferedReader br = FileUtility.getBufferReader("BEM Map.csv");
	List<List<String>> services = new ArrayList<List<String>>();
	String line;
	while ((line = br.readLine()) != null) {
	    List<String> serviceData = new ArrayList<String>(Arrays.asList(line.split(COMMA_SEPARATOR)));
	    services.add(serviceData);
	    ShmService shm = fetchService(serviceData);
	    shmServices.add(shm);

	}

	System.out.println("Number of lines:" + services.size());

    }

    private static ShmService fetchService(List<String> column) {
	String name = column.get(0);
	ShmService shm = new ShmService();
	shm.setName(name);
	if (SHM_TimeAuditGraphs.sHMAverageMap.get(name) != null) {
	    shm.setTimeTaken(SHM_TimeAuditGraphs.sHMAverageMap.get(name));
	}

	column.remove(column.get(0));
	shm.setbEMServicesCalled(column);
	System.out.println(shm);
	return shm;

    }

}
