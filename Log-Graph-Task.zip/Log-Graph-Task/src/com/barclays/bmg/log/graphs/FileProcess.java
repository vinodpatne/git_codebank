package com.barclays.bmg.log.graphs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.binary.Hex;

public class FileProcess {

    private static String COMMA_SEPARATOR = ",";

    public static void main(String[] args) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
	    InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	// public void getProcessFile(File filepath) {

	String sourceCsvFile = "C:\\SOFTTAG\\Mayuri\\Server_1_2_Combine.csv";

	BufferedReader br = null;
	String line = "";
	String cvsSplitBy = "\\|\\|";
	BufferedWriter bufferWritter1 = null;
	BufferedWriter bufferWritter2 = null;
	String IV = "770A8A65DA156D24";
	String KEY = "990A8A65DA156D24";
	byte[] encrypt = null;
	File file1 = new File("./data/node/TIME_AUDIT.csv");
	File file2 = new File("./data/node/BEM_SERVICE_BREAKUP.csv");

	try {

	    // File file1 = new File("./data/node/TIME_AUDIT.csv");
	    // File file2 = new File("./data/node/BEM_SERVICE_BREAKUP.csv");
	    int cnt = 1;

	    String pattern = "ddMMyyyy";
	    SimpleDateFormat format = new SimpleDateFormat(pattern);

	    // if file doesnt exists, then create it
	    if (!file1.exists()) {
		file1.createNewFile();
	    }
	    // if file doesnt exists, then create it
	    if (!file2.exists()) {
		file2.createNewFile();
	    }

	    // true = append file
	    FileWriter fileWritter1 = new FileWriter(file1, false);
	    bufferWritter1 = new BufferedWriter(fileWritter1);

	    bufferWritter2 = new BufferedWriter(new FileWriter(file2, false));

	    System.out.println("Done");

	    br = new BufferedReader(new FileReader(sourceCsvFile));
	    int id = 0;
	    while ((line = br.readLine()) != null) {
		String timeStamp = getTimeStamp(line);
		String mobileNumber = getMobileNumber(line);
		Encrypter encrypter = new Encrypter();
		encrypt = encrypter.encrypt(IV.getBytes(), KEY.getBytes(), mobileNumber.getBytes());
		String hexEncodedMobileNum = String.valueOf(Hex.encodeHex(encrypt));

		line = line.replaceAll(";", ",");

		String[] record = line.split(cvsSplitBy);
		String firstString = record[0];

		// int pipeIndex = line.indexOf(cvsSplitBy);
		// String firstString = line.substring(0, pipeIndex - 1);
		String encodedFirstString = firstString.replaceAll(mobileNumber, hexEncodedMobileNum);

		String transID = format.format(new Date()) + "_" + cnt;
		String secString = null;

		if (record.length > 1) {

		    bufferWritter1.write(transID + ",");
		    bufferWritter1.write(encodedFirstString);
		    bufferWritter1.write("\n");

		    if (!(record[1].trim().equals(""))) {

			for (int index = 1; index < record.length; index++) {
			    id++;
			    bufferWritter2.write(id + COMMA_SEPARATOR);
			    bufferWritter2.write(transID + COMMA_SEPARATOR);
			    bufferWritter2.write(timeStamp + COMMA_SEPARATOR);
			    bufferWritter2.write(record[index]);
			    bufferWritter2.write("\n");

			}

		    }
		    // line only contain ] and error message contain ,
		} else {
		    bufferWritter1.write(transID + ",");
		    bufferWritter1.write(encodedFirstString);
		    bufferWritter1.write("\n");

		}

		cnt++;

	    }

	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	} catch (IOException e) {
	    e.printStackTrace();
	} finally {
	    if (br != null) {
		try {
		    br.close();
		    bufferWritter1.close();
		    bufferWritter2.close();
		    mergeHeader(file1, file2);
		} catch (IOException e) {
		    e.printStackTrace();
		}
	    }
	}

	System.out.println("Done");

    }

    private static void mergeHeader(File f1, File f2) throws IOException {
	RandomAccessFile timeAudit = new RandomAccessFile(f1.getAbsolutePath(), "rws");
	RandomAccessFile bemBreakup = new RandomAccessFile(f2.getAbsolutePath(), "rws");

	byte[] text = new byte[(int) bemBreakup.length()];
	bemBreakup.readFully(text);
	bemBreakup.seek(0);
	bemBreakup
		.writeBytes("Transaction_ID,Time_Stamp,ServiceId,ConsumerRefNo,CategoryId,Response,Service_Time,BemError,Host,PP_Error_Code,PP_Error_Desc"
			+ "\n");

	bemBreakup.write(text);
	bemBreakup.close();

	byte[] text1 = new byte[(int) timeAudit.length()];
	timeAudit.readFully(text1);
	timeAudit.seek(0);
	timeAudit
		.writeBytes("Transaction_ID,Time_Stamp,Session_Id,Business_ID,Mobile_Number,Opcode,Response,Respose_Code,SHM_Response_Time,BEM_Response_Time"
			+ "\n");
	timeAudit.write(text1);
	timeAudit.close();

	System.out.println("Done");

    }

    private static String getTimeStamp(String line) {
	String[] column;
	column = line.split(COMMA_SEPARATOR);
	String timeStamp = column[0];
	return timeStamp;
    }

    private static String getMobileNumber(String line) {
	String[] column;
	column = line.split(COMMA_SEPARATOR);
	String mobileNum = column[3];

	return mobileNum;
    }
    // }
}
