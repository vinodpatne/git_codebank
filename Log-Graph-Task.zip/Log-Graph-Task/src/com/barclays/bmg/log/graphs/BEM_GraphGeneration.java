package com.barclays.bmg.log.graphs;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;

import com.barclays.bmg.pojo.Activity;
import com.barclays.bmg.pojo.FileUtility;

public class BEM_GraphGeneration {
    private static final int TIME_STAMP_COLUMN_NUMBER = 0;
    private static final int SESSION_ID_COLUMN_NUMBER = 2;
    private static int SERVICE_NAME_COLUMN_NUMBER = 3;
    private static int SUCCESS_COLUMN_NUMBER = 4;
    private static int RESPONSE_TIME_COLUMN_NUMBER = 5;

    private static final String TEMP_DIR_LOCATION = System.getProperty("java.io.tmpdir", "./");

    private static String SERVICE = "Service";
    private static String COMMA_SEPARATOR = ",";

    private static String SERVICE_COUNT_TITLE = "Service Count of the Day";
    private static String SERVICE_COUNT_CHART_NAME = "Service_Counts_Column_Chart.jpg";
    private static String BACKEND_PERFORMANCE_TITLE = "Backend Performance Response";
    private static String BACKEND_PERFORMANCE_CHART_NAME = "Backend_Performance_Response_Column_Chart.jpg";
    private static String TRANSACTION_FAILURE_CHART_NAME = "Transaction_Failure_Response_Column_Chart.jpg";
    private static String TRANSACTION_FAILURE_TITLE = "Transaction Failure Count";
    private static String HOURLY_LOGIN_FREQUENCY_TITLE = "Hourly Login Frequency";
    private static String HOURLY_LOGIN_FREQUENCY_CHART_NAME = "Hourly_Login_Frequency.jpg";

    private static Color BACKGROUND_COLOR = Color.white;
    private static Color BLUE = new Color(78, 131, 197);
    private static Color RED = new Color(194, 78, 79);
    private static Color GREEN = new Color(157, 187, 99);

    private static String vbsTemplateFileLocation = "email-sender/Email_Macro_Caller-Template.vbs";

    private static Map<String, Integer> hourlyOffset = new HashMap<String, Integer>();

    static int totalLoginCountService;
    private static List<String> filePaths;
    public static Map<String, Double> averageMap;

    public static void main(String[] args) throws IOException, ParseException {

	hourlyOffset.put("TZ", 3);
	hourlyOffset.put("UG", 3);
	hourlyOffset.put("GH", 0);
	hourlyOffset.put("KE", 3);

	List<Activity> activities = getActivitiesFromCSV("BEM.csv");

	filePaths = new ArrayList<String>();
	averageMap = new HashMap<String, Double>();
	// prepareServiceCountGraph(activities, filePaths);
	prepareHLFGraph(activities, filePaths);
	// prepareTransactionFailuresGraph(activities, filePaths);
	prepareBEMPerformanceGraph(activities, filePaths, averageMap);
	System.out.println("Files Made");
	// sendEmail("23", "34", "");

    }

    /************************************************ PREPARE ACTIVITY OBJECT *********************************************************/
    private static List<Activity> getActivitiesFromCSV(String csvFile) throws IOException, ParseException {
	BufferedReader br = FileUtility.getBufferReader(csvFile);

	String line;
	List<Activity> activities = new ArrayList<Activity>();
	while ((line = br.readLine()) != null) {
	    Activity activity = getActivity(line);
	    if (activity.getMobileNo() != null)
		activities.add(activity);

	}

	return activities;
    }

    private static Activity getActivity(String line) throws ParseException {
	String[] column = line.split(COMMA_SEPARATOR);
	Activity activity = new Activity();
	if (column.length > 5) {
	    DateFormat readFormat = new SimpleDateFormat("yyyy-MMM-dd hh:mm:ss.SSS");
	    activity.setTimeStamp(readFormat.parse(column[TIME_STAMP_COLUMN_NUMBER].substring(1)));
	    activity.setCountry(fetchCountry(column[SESSION_ID_COLUMN_NUMBER]));
	    activity.setMobileNo(fetchMobile(column[SESSION_ID_COLUMN_NUMBER]));
	    activity.setService(column[SERVICE_NAME_COLUMN_NUMBER].trim());
	    activity.setResponse(column[SUCCESS_COLUMN_NUMBER]);
	    int length = column[RESPONSE_TIME_COLUMN_NUMBER].length();

	    System.out.println(activity);
	    System.out.println(length + " " + column[RESPONSE_TIME_COLUMN_NUMBER].substring(0, column[RESPONSE_TIME_COLUMN_NUMBER].indexOf("ms")));
	    activity.setResponseTime(Integer.parseInt(column[RESPONSE_TIME_COLUMN_NUMBER].substring(0, column[RESPONSE_TIME_COLUMN_NUMBER]
		    .indexOf("ms"))));

	}
	return activity;
    }

    private static String fetchMobile(String sessionID) {
	int length = sessionID.length();
	String mobileNo = sessionID.substring(length - 14, length - 2);

	return mobileNo;
    }

    private static String fetchCountry(String sessionID) {
	int length = sessionID.length();
	String country = sessionID.substring(sessionID.indexOf("BRB") - 2, sessionID.indexOf("BRB"));
	return country;

    }

    /************************************************ SERVICE COUNT GRAPH *********************************************************/
    private static void prepareServiceCountGraph(List<Activity> activities, List<String> filePaths) throws IOException {
	String serviceCountFilePath = getFileName(SERVICE_COUNT_CHART_NAME, filePaths);
	DefaultCategoryDataset serviceCountDataset = createServiceCountDataset(activities);
	JFreeChart serviceCountChart = ChartFactory.createBarChart(SERVICE_COUNT_TITLE, SERVICE, SERVICE + "Count", serviceCountDataset,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot = getPlot(serviceCountChart);
	BarRenderer renderer = (BarRenderer) plot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesPaint(0, GREEN);

	ChartUtilities.saveChartAsJPEG(new File(serviceCountFilePath), serviceCountChart, 1300, 800);

    }

    private static DefaultCategoryDataset createServiceCountDataset(List<Activity> activities) throws IOException {

	Map<String, Integer> serviceToCountMap = new HashMap<String, Integer>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	System.out.println(activities.size());

	for (Activity activity : activities) {

	    System.out.println(activity);
	    if (isNotServiceFault(activity.getService()) && isValidDate(activity.getTimeStamp())) {

		serviceToCountMap = addDataToMap(serviceToCountMap, activity.getService());
		dataset.setValue(serviceToCountMap.get(activity.getService()), SERVICE, activity.getService());
	    }
	}

	return dataset;
    }

    /************************************************ BEM PERFORMANCE GRAPH *********************************************************/
    private static void prepareBEMPerformanceGraph(List<Activity> activities, List<String> filePaths, Map<String, Double> averageMap)
	    throws IOException {

	DefaultCategoryDataset backendPerformance = createBPerformanceCountDataset(activities, averageMap);
	JFreeChart chart = ChartFactory.createBarChart(BACKEND_PERFORMANCE_TITLE, SERVICE, "Response Time (sec)", backendPerformance,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot bemPerformancePlot = getPlot(chart);
	BarRenderer renderer = (BarRenderer) bemPerformancePlot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(1, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(2, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));

	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesItemLabelsVisible(1, true);
	renderer.setSeriesItemLabelsVisible(2, true);
	renderer.setSeriesPaint(0, BLUE);
	renderer.setSeriesPaint(1, RED);
	renderer.setSeriesPaint(2, GREEN);
	renderer.setSeriesPaint(3, new Color(128, 100, 159));

	renderer.setItemMargin(.002);

	int columnCount = backendPerformance.getColumnCount();
	String backendPerformanceFile = getFileName(BACKEND_PERFORMANCE_CHART_NAME, filePaths);
	int xDimension = columnCount * 100 < 1500 ? 1500 : (columnCount * 100);
	int yDimension = xDimension * 5 / 10;
	ChartUtilities.saveChartAsJPEG(new File(backendPerformanceFile), chart, xDimension, yDimension);

    }

    private static DefaultCategoryDataset createBPerformanceCountDataset(List<Activity> activities, Map<String, Double> averageMap)
	    throws IOException {

	Map<String, List<Double>> serviceToResponseTimesMap = new HashMap<String, List<Double>>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	for (Activity activity : activities) {

	    if (isNotServiceFault(activity.getService()) && isValidDate(activity.getTimeStamp())) {

		if (activity.getResponse().equals("Success")) {

		    serviceToResponseTimesMap = addResponseTimetoService(serviceToResponseTimesMap, activity.getService(), activity.getResponseTime());
		    List<Double> responseTimes = serviceToResponseTimesMap.get(activity.getService());
		    Double averageResponseTime = getAverageFromList(responseTimes);

		    Double ninetyPerc = getNinetyPerc(responseTimes);
		    Double tenPerc = getTenPerc(responseTimes);

		    averageMap.put(activity.getService(), averageResponseTime);
		    dataset.setValue(tenPerc, "Min", activity.getService());
		    dataset.setValue(averageResponseTime, "Average", activity.getService());
		    dataset.setValue(ninetyPerc, "Max", activity.getService());

		}
	    }
	}

	return dataset;

    }

    private static Double getNinetyPerc(List<Double> responseTimes) {
	Collections.sort(responseTimes);
	int length = responseTimes.size();
	int ninetieth = (int) (length * 0.9);
	Double nineth = responseTimes.get(ninetieth);
	return (double) Math.round(nineth * 10) / 10;

    }

    private static Double getTenPerc(List<Double> responseTimes) {
	Collections.sort(responseTimes);
	int length = responseTimes.size();
	int ninetieth = (int) (length * 0.1);
	Double nineth = responseTimes.get(ninetieth);
	return (double) Math.round(nineth * 10) / 10;

    }

    private static Map<String, List<Double>> addResponseTimetoService(Map<String, List<Double>> graphData, String serviceName, double d) {

	List<Double> responseTimes = new ArrayList<Double>();
	if (graphData.get(serviceName) != null) {
	    responseTimes = graphData.get(serviceName);
	}
	responseTimes.add((double) (d / 1000));
	graphData.put(serviceName, responseTimes);
	return graphData;
    }

    private static Double getAverageFromList(List<Double> responseTimes) {

	Double sum = 0.0;
	for (int i = 0; i < responseTimes.size(); i++) {

	    sum += responseTimes.get(i);
	}
	Double avg = (sum / responseTimes.size());

	return (double) Math.round(avg * 10) / 10;
    }

    /************************************************ TRANSACTION FAILURE GRAPH *********************************************************/
    private static void prepareTransactionFailuresGraph(List<Activity> activities, List<String> filePaths) throws IOException {
	DefaultCategoryDataset transactionFailures = createServiceFailureCountDataset(activities);
	JFreeChart tFChart = ChartFactory.createBarChart(TRANSACTION_FAILURE_TITLE, SERVICE, "Failure Count", transactionFailures,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot2 = getPlot(tFChart);
	final CategoryItemRenderer renderer2 = plot2.getRenderer();

	renderer2.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer2.setSeriesItemLabelsVisible(0, true);
	renderer2.setSeriesPaint(0, RED);
	String TransactionFailureFile = getFileName(TRANSACTION_FAILURE_CHART_NAME, filePaths);
	ChartUtilities.saveChartAsJPEG(new File(TransactionFailureFile), tFChart, 900, 700);

    }

    private static DefaultCategoryDataset createServiceFailureCountDataset(List<Activity> activities) throws IOException {

	Map<String, Integer> serviceToFailureCountMap = new HashMap<String, Integer>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	List<String> failureCodeList = new ArrayList<String>(5);
	failureCodeList.add("BMB90004");
	failureCodeList.add("BMB99999");
	failureCodeList.add("BEM08744");
	failureCodeList.add("BEM08729");
	failureCodeList.add("BEM08777");
	for (Activity activity : activities) {

	    if (isNotServiceFault(activity.getService()) && isValidDate(activity.getTimeStamp())) {
		{
		    if (activity.getResponse().equals("Error")) {
			if (!(activity.getService().equals("RetrieveCustomerQuestionnaire")) && failureCodeList.contains(activity.getResponseCode())) {
			    serviceToFailureCountMap = addDataToMap(serviceToFailureCountMap, activity.getService());
			    dataset.setValue(serviceToFailureCountMap.get(activity.getService()), SERVICE, activity.getService());
			}
		    }
		}

	    }

	}

	return dataset;
    }

    /************************************************ HOURLY FREQUENCY GRAPH *********************************************************/
    private static void prepareHLFGraph(List<Activity> activities, List<String> filePaths) throws IOException {
	DefaultCategoryDataset hourlyLoginFrequencyDataset = createHLFDataset(activities);
	JFreeChart hLFChart = ChartFactory.createBarChart(HOURLY_LOGIN_FREQUENCY_TITLE, "Time (Hours)", SERVICE + " Count",
		hourlyLoginFrequencyDataset, PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot1 = getPlot(hLFChart);

	final CategoryItemRenderer renderer1 = plot1.getRenderer();

	renderer1.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer1.setSeriesItemLabelsVisible(0, true);

	String HourlyFrequencyFile = getFileName(HOURLY_LOGIN_FREQUENCY_CHART_NAME, filePaths);
	ChartUtilities.saveChartAsJPEG(new File(HourlyFrequencyFile), hLFChart, 1000, 800);

    }

    private static DefaultCategoryDataset createHLFDataset(List<Activity> activities) throws IOException {

	Map<String, Integer> uniqueNumberLoginsPerHourMap = new HashMap<String, Integer>();
	Map<String, Integer> fullDayLogintoCountMap = new HashMap<String, Integer>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	List<String> mobileNumbersAndHours = new ArrayList<String>();
	List<String> mobileNumbers = new ArrayList<String>();
	for (Activity activity : activities) {

	    if (isNotServiceFault(activity.getService()) && isValidDate(activity.getTimeStamp())) {
		if (activity.getService().equals("VerifyPin")) {

		    String hour = fetchHour(activity.getTimeStamp(), activity.getCountry());

		    String mobileNoAndHr = activity.getMobileNo() + hour;
		    if (!(mobileNumbersAndHours.contains(mobileNoAndHr))) {
			uniqueNumberLoginsPerHourMap = addDataToMap(uniqueNumberLoginsPerHourMap, hour);
			mobileNumbersAndHours.add(mobileNoAndHr);
		    }
		    if (!(mobileNumbers.contains(activity.getMobileNo()))) {
			fullDayLogintoCountMap = addDataToMap(fullDayLogintoCountMap, hour);
			mobileNumbers.add(activity.getMobileNo());
		    }
		}
	    }
	}

	for (Integer i = 100; i < 124; i++) {
	    String hour = i.toString();
	    hour = hour.substring(1);
	    dataset.setValue(uniqueNumberLoginsPerHourMap.get(hour), SERVICE, hour);
	}

	System.out.println("Full day active users login count: " + totalLoginCount(fullDayLogintoCountMap));
	return dataset;

    }

    private static String fetchHour(Date inputDate, String country) {

	DateFormat writeFormat = new SimpleDateFormat("HH");
	System.out.println(inputDate);
	inputDate = DateUtils.addHours(inputDate, hourlyOffset.get(country));
	String formattedDate = "";
	if (inputDate != null) {
	    formattedDate = writeFormat.format(inputDate);
	}
	return formattedDate;
    }

    private static int totalLoginCount(Map<String, Integer> graphData) {

	Integer loginTotal = 0;
	for (Integer value : graphData.values()) {
	    loginTotal = loginTotal + value; // Can also be done by total += value;
	}

	return loginTotal;

    }

    @SuppressWarnings("unused")
    private static void sendEmail(String loginCount, String registrations, String date) throws FileNotFoundException, IOException {/*
																    * 
																    * //String
																    * bodyText =
																    * FileUtility
																    * .readContents
																    * ("template.txt"
																    * );
																    * System.out.println
																    * (bodyText);
																    * 
																    * Format formatter
																    * = new
																    * SimpleDateFormat
																    * ("dd-MMM-yyyy");
																    * 
																    * date =
																    * formatter.
																    * format(
																    * DateUtils.
																    * addDays(new
																    * Date(), -1));
																    * bodyText =
																    * bodyText
																    * .replaceAll
																    * ("<<attachment1>>"
																    * ,
																    * BACKEND_PERFORMANCE_CHART_NAME
																    * ); bodyText =
																    * bodyText
																    * .replaceAll
																    * ("<<attachment2>>"
																    * ,
																    * HOURLY_LOGIN_FREQUENCY_CHART_NAME
																    * ); bodyText =
																    * bodyText
																    * .replaceAll
																    * ("<<attachment3>>"
																    * ,
																    * SERVICE_COUNT_CHART_NAME
																    * );
																    * 
																    * EmailMessage
																    * message = new
																    * EmailMessage();
																    * message
																    * .setToRecipients
																    * (
																    * "shivang.balkiwal@barlayscorp.com"
																    * );
																    * 
																    * Properties prop
																    * = new
																    * Properties();
																    * prop.load(new
																    * FileInputStream(
																    * "config/log-graph-task-config.properties"
																    * ));message.
																    * setToRecipients
																    * (prop
																    * .getProperty
																    * ("TO"));
																    * message.
																    * setCcRecipients
																    * (prop
																    * .getProperty
																    * ("CC"));
																    * message.
																    * setBccRecipients
																    * (
																    * prop.getProperty
																    * ("BCC"));
																    * message
																    * .setSubject
																    * (prop.
																    * getProperty
																    * ("Subject"));
																    * 
																    * String subject =
																    * "SHM TZ PROD | Services response reports "
																    * + date;
																    * 
																    * // pradnya
																    * 
																    * String
																    * vbsFileName =
																    * "email-sender/outbox/"
																    * +
																    * "Email-Notification-"
																    * +System.
																    * currentTimeMillis
																    * () + ".vbs";
																    * 
																    * message.
																    * setFileAttachment
																    * (filePaths);
																    * String
																    * serviceNameTemp
																    * = "";
																    * 
																    * String
																    * sendEmailCall =
																    * "xlApp.Run \"SendDowntimeEmail\", \""
																    * +message.
																    * getToRecipients
																    * () + "\","
																    * 
																    * + "\"" +
																    * message.
																    * getCcRecipients
																    * () + "\", " +
																    * "\"" +message.
																    * getBccRecipients
																    * () + "\", " +
																    * "\"" + subject +
																    * "\",  " + "\"" +
																    * date + "\", " +
																    * "\"" +
																    * loginCount +
																    * "\",  " + "\"" +
																    * registrations +
																    * "\", \"High\",\""
																    * +
																    * HOURLY_LOGIN_FREQUENCY_CHART_NAME
																    * + "\",\"" +
																    * SERVICE_COUNT_CHART_NAME
																    * + "\",\"" +
																    * BACKEND_PERFORMANCE_CHART_NAME
																    * + "\", \"" +
																    * filePaths.get(0)
																    * + "\", \"" +
																    * filePaths.get(1)
																    * + "\",\"" +
																    * filePaths.get(2)
																    * + "\",\"" +
																    * filePaths.get(3)
																    * + "\"";
																    * 
																    * 
																    * 
																    * System.out.println
																    * (sendEmailCall);
																    * 
																    * String
																    * templateData =
																    * IOUtils
																    * .toString(new
																    * FileInputStream(
																    * vbsTemplateFileLocation
																    * )); ; String
																    * data =
																    * templateData
																    * .replace
																    * ("'SEND_EMAIL_CALL"
																    * ,
																    * sendEmailCall);
																    * FileUtility
																    * .writeToFile
																    * (vbsFileName,
																    * data, false);
																    */
    }

    /************************************************* COMMON METHODS ****************************************************************/
    private static String getFileName(String fileName, List<String> filePaths) {
	String filePath = TEMP_DIR_LOCATION + fileName;
	filePaths.add(filePath);
	System.out.println(filePath);
	return filePath;
    }

    private static Map<String, Integer> addDataToMap(Map<String, Integer> graphData, String serviceName) {

	int serviceCount;
	if (graphData.get(serviceName) != null) {
	    serviceCount = graphData.get(serviceName);
	    serviceCount++;
	} else {
	    serviceCount = 1;

	}
	graphData.put(serviceName, serviceCount);
	return graphData;
    }

    private static CategoryPlot getPlot(JFreeChart chart) {
	CategoryPlot plot = (CategoryPlot) chart.getPlot();
	CategoryAxis xAxis3 = (CategoryAxis) plot.getDomainAxis();

	xAxis3.setCategoryLabelPositions(CategoryLabelPositions.UP_45);

	TextTitle title = chart.getTitle();
	Font titleFont = new Font("TimesRoman", Font.BOLD, 25);
	title.setFont(titleFont);
	chart.setTitle(title);
	BarRenderer renderer = (BarRenderer) plot.getRenderer();
	renderer.setMaximumBarWidth(0.03);

	renderer.setDrawBarOutline(true);
	renderer.setBarPainter(new StandardBarPainter());
	renderer.setShadowVisible(false);
	renderer.setSeriesPaint(0, BLUE);
	plot.setRangeGridlinePaint(Color.gray);
	plot.setRangeGridlinesVisible(true);
	chart.setBackgroundPaint(BACKGROUND_COLOR);
	plot.setBackgroundPaint(BACKGROUND_COLOR);
	plot.setOutlineVisible(true);
	return plot;
    }

    private static boolean isNotServiceFault(String service) {

	return !("serviceFault".equals(service));
    }

    private static boolean isValidDate(Date inputDate) {

	/*
	 * Date yesterday = DateUtils.addDays(new Date(), -1); DateFormat onlyDate = new SimpleDateFormat("yyyy-MMM-dd"); String yesterdayFormatted =
	 * onlyDate.format(yesterday);
	 * 
	 * String inputFormatted = onlyDate.format(inputDate);
	 * 
	 * if (!(inputFormatted.equals(yesterdayFormatted))) { return false; }
	 */

	return true;
    }

}
