package com.barclays.bmg.log.graphs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Properties;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

/**
 * 
 * @author jayshri
 * @version 0.1
 */
public class FtpTestClient {

    public final static int DEFAULT_FTP_PORT = 22;

    private FTPClient ftpc;
    public static String server;
    public static String username;
    public static String password;
    public static String folder;
    public static String ftempl;

    public static void main(String[] args) throws FileNotFoundException {

	// String host_names = "howl6701.unix.barclays.co.uk";
	String host_names = "124.2.24.10";
	String user_names;
	String passwords;
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	Calendar cal = GregorianCalendar.getInstance();
	cal.add(Calendar.DATE, -1);

	String yesterday = dateFormat.format(cal.getTime());

	// /wload/yc7p/app/logs/base/yc7p-shm01-server01/hellomoney_soap.log

	// String ftp_src_folder = "/wload/yc7p/app/logs/base/yc7p-shm01-server01";
	String ftp_src_folder = "/ftp/bir-deploy-pct/ussdhellomoney";
	// String destinationFolder = "C:\\softtag\\SHM";
	String destinationFolder = "C:\\softtag\\BEM LOGS";
	String ftp_src_file = "SystemErr.log";
	String uname;
	String pass;

	// prompt the user to enter their name

	/*
	 * BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); String userName = null; String password = null; try {
	 * System.out.print("Enter user name: "); userName = br.readLine(); System.out.print("Enter Password : "); password = br.readLine(); } catch
	 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace(); }
	 */
	Properties props = new Properties();
	InputStream inputStream = new FileInputStream("log-graph-task-config.properties");
	// InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("log-graph-task-config.properties");
	try {
	    props.load(inputStream);
	    inputStream.close();
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

	String userName = props.getProperty("user.name");
	String password = props.getProperty("user.password");

	// getAllFiles(server, username, password, folder, destinationFolder, new Date(yesterday));
	System.out.println("" + userName + password);
	// for (int i = 0; i < host_names.length; i++) {
	FtpTestClient.getFile(host_names, userName, password, ftp_src_folder, destinationFolder);
	// FtpTestClient.getFile(host_names[i], user_names[i], passwords[i], ftp_src_folder, ftp_src_file);
	// FtpTestClient.getAllFiles(host_names[i], user_names[i], passwords[i], ftp_src_folder, destinationFolder, yesterday);
	/*
	 * try { FtpTestClient.getFilesOfType(server, username, password, folder, ftempl); } catch (Exception e) { // TODOAuto-generated catch block
	 * e.printStackTrace(); } }
	 */

	System.out.println("+++++++++++++++++");
	// }
    }

    /*
     * public FtpTestClient(String host, String login, String passwd) throws Exception { this(host, String.valueOf(FtpTestClient.DEFAULT_FTP_PORT),
     * login, passwd); }
     */

    public FtpTestClient(String server, String username, String password, String folder, String ftempl) throws Exception {
	this.server = server;
	this.username = username;
	this.password = password;
	this.folder = folder;
	this.ftempl = ftempl;

    }

    /**
     * Creates a new instance of FtpTestClient
     * 
     * 
     * @param host
     *            Server host name
     * @param port
     *            Server port number
     * @param login
     *            FTP login name
     * @param passwd
     *            FTP login password
     * @throws Exception
     *             if client create fails
     */
    /*
     * public FtpTestClient(String host, String port, String login, String passwd) throws Exception { try { ftpc = new FTPClient(); } catch (Exception
     * e) { throw new Exception(e.getMessage()); } }
     */

    /**
     * get a single file from the server. Destination filename is same as that on server.
     * 
     * @param server
     *            ftp server name
     * @param username
     *            ftp server login name
     * @param password
     *            ftp server password
     * @param folder
     *            source folder on the ftp server
     * @param fname
     *            file to be transferred
     * @return true if successful
     */
    public static boolean getFile(String server, String username, String password, String folder, String destfolder) {
	boolean status = false;

	FTPClient ftp = null;
	try {
	    ftp = new FTPClient();

	    ftp.connect(server);
	    ftp.login(username, password);

	    ftp.changeWorkingDirectory(folder);

	    /*
	     * File file = new File(fname); FileOutputStream fos = new FileOutputStream(file);
	     * 
	     * ftp.retrieveFile(fname, fos); System.out.println("File is generated"); fos.close();
	     * 
	     * status = true;
	     */
	    FTPFile[] files = ftp.listFiles();

	    System.out.println("Number of files in dir: " + files.length);
	    for (int i = 0; i < files.length; i++) {

		Date fileDate = files[i].getTimestamp().getTime();

		// String date = start + ".bak";
		String fileName = files[i].getName();

		if (fileName.startsWith("System")) {
		    // Download a file from the FTP Server
		    // System.out.print(df.format(files[i].getTimestamp().getTime()));
		    // System.out.println("*" + "\t" + files[i].getName());
		    File file = new File(destfolder + File.separator + files[i].getName());
		    FileOutputStream fos = new FileOutputStream(file);
		    ftp.retrieveFile(files[i].getName(), fos);
		    fos.close();

		    /*
		     * if (fileName.startsWith("hellomoney_audit-time") && fileName.endsWith(date)) {
		     * 
		     * File file = new File(auditDestinationFolder + File.separator + files[i].getName()); FileOutputStream fos = new
		     * FileOutputStream(file); ftp.retrieveFile(files[i].getName(), fos); fos.close();
		     * 
		     * } else if (fileName.startsWith("hellomoney_bem_tat") && fileName.endsWith(date)) { File file = new File(bemDestinationFolder +
		     * File.separator + files[i].getName()); FileOutputStream fos = new FileOutputStream(file); ftp.retrieveFile(files[i].getName(),
		     * fos); fos.close(); }
		     */

		}
	    }

	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    try {
		ftp.logout();
		ftp.disconnect();
	    } catch (Exception e) {
	    }
	}

	return status;
    }

    public static void getAllFiles(String server, String username, String password, String folder, String destinationFolder, String start) {
	try {
	    // Connect and logon to FTP Server

	    FTPClient ftp = new FTPClient();
	    ftp.connect(server);
	    ftp.login(username, password);
	    System.out.println("Connected to " + server + ".");
	    System.out.print(ftp.getReplyString());

	    // hellomoney_audit-time.csv.2014-09-22.bak
	    // hellomoney_bem_tat.csv.2014-09-22.bak

	    // List the files in the directory
	    ftp.changeWorkingDirectory(folder);

	    FTPFile[] files = ftp.listFiles();

	    System.out.println("Number of files in dir: " + files.length);
	    DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
	    for (int i = 0; i < files.length; i++) {

		Date fileDate = files[i].getTimestamp().getTime();

		String date = start + ".bak";
		String fileName = files[i].getName();

		if (fileName.startsWith("ussd")) {
		    // Download a file from the FTP Server
		    // System.out.print(df.format(files[i].getTimestamp().getTime()));
		    // System.out.println("*" + "\t" + files[i].getName());

		    File file = new File(destinationFolder + File.separator + files[i].getName());
		    FileOutputStream fos = new FileOutputStream(file);
		    ftp.retrieveFile(files[i].getName(), fos);
		    fos.close();

		    /*
		     * if (fileName.startsWith("hellomoney_audit-time") && fileName.endsWith(date)) {
		     * 
		     * File file = new File(auditDestinationFolder + File.separator + files[i].getName()); FileOutputStream fos = new
		     * FileOutputStream(file); ftp.retrieveFile(files[i].getName(), fos); fos.close();
		     * 
		     * } else if (fileName.startsWith("hellomoney_bem_tat") && fileName.endsWith(date)) { File file = new File(bemDestinationFolder +
		     * File.separator + files[i].getName()); FileOutputStream fos = new FileOutputStream(file); ftp.retrieveFile(files[i].getName(),
		     * fos); fos.close(); }
		     */

		}

		// Logout from the FTP Server and disconnect
		ftp.logout();
		ftp.disconnect();

	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    /**
     * Gets all files which matches a specified file name template. The template is a regular expression.
     * 
     * @param server
     *            ftp server name
     * @param username
     *            ftp server login name
     * @param password
     *            ftp server password
     * @param folder
     *            source folder on the ftp server
     * @param ftempl
     *            regular expression for file name
     * @return true if successful
     * @throws Exception
     *             if unable to connect and other problems.
     */
    public static boolean getFilesOfType(String server, String username, String password, String folder, String ftempl) throws Exception {
	FTPClient ftp = null;
	boolean status = false;

	try {
	    // Connect and logon to FTP Server
	    ftp = new FTPClient();
	    ftp.connect(server);
	    ftp.login(username, password);

	    // List the files in the directory

	    ftp.changeWorkingDirectory(folder);
	    FTPFile[] files = ftp.listFiles();

	    // get files which match name template
	    // at present just check for prefix
	    for (int i = 0; i < files.length; i++) {
		/*
		 * if (files[i].matches(ftempl)) {
		 * 
		 * }
		 */
	    }
	} catch (Exception e) {
	    throw e;
	}

	finally {
	    // close connection
	    if (ftp != null && ftp.isConnected()) {
		ftp.disconnect();
	    }
	}

	return status;
    }

    /**
     * Upload a single file to the server. Destination filename is same as that on server.
     * 
     * @param server
     *            ftp server name
     * @param username
     *            ftp server login name
     * @param password
     *            ftp server password
     * @param folder
     *            source folder on the ftp server
     * @param fname
     *            file to be transferred
     * @return true if successful
     */
    public boolean putFile(String server, String username, String password, String folder, String fname) throws Exception {
	return false;
    }

    public void setMode(int type) {

    }

    public int getMode() {
	return -1;
    }

}