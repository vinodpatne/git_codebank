package com.barclays.bmg.log.graphs;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DirectoryListUtil {

    /**
     * List all files from a directory and its subdirectories
     * 
     * @param directoryName
     *            to be listed
     */

    private List<String> bemFileName = new ArrayList<String>();
    private List<String> auditFileName = new ArrayList<String>();

    public List<String> getBemFileName() {
	return bemFileName;
    }

    public void setBemFileName(List<String> bemFileName) {
	this.bemFileName = bemFileName;
    }

    public List<String> getAuditFileName() {
	return auditFileName;
    }

    public void setAuditFileName(List<String> auditFileName) {
	this.auditFileName = auditFileName;
    }

    public void listFilesAndFilesSubDirectories(String directoryName) {

	File directory = new File(directoryName);

	// get all the files from a directory
	File[] fList = directory.listFiles();

	for (File file : fList) {
	    if (file.isFile() && file.getName().startsWith("BEM")) {
		// System.out.println(file.getAbsolutePath());
		bemFileName.add(file.getAbsolutePath());
	    } else if (file.isFile() && file.getName().startsWith("Time")) {
		// System.out.println(file.getAbsolutePath());
		auditFileName.add(file.getAbsolutePath());
	    } else if (file.isDirectory()) {
		listFilesAndFilesSubDirectories(file.getAbsolutePath());
	    }
	}
    }

}
