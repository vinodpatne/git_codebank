package com.barclays.bmg.log.graphs;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.time.DateUtils;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import com.barclays.bmg.pojo.Activity;
import com.barclays.bmg.pojo.FileUtility;

public class SHM_TimeAuditGraphs {
    private static final int TIME_STAMP_COLUMN_NUMBER = 0;
    private static final int SESSION_ID_COLUMN_NUMBER = 1;
    private static final int OPCODE_COLUMN_NUMBER = 2;
    private static final int RESPONSE_COLUMN_NUMBER = 3;
    private static final int RESPONSE_CODE_COLUMN_NUMBER = 4;
    private static final int FAILURE_COLUMN_NUMBER = 4;
    private static final int PPCODE_COLUMN_NUMBER = 5;
    private static final int BEM_ERROR_COLUMN_NUMBER = 3;
    private static final int PPCODE_COLUMN_DESCRIPTION = 6;
    private static final int SERVICE_COLUMN_NUMBER = 7;
    private static final int URN_COLUMN_NUMBER = 2;
    // private static final int CATEGORY_COLUMN_NUMBER = 8;

    private static int RESPONSE_TIME_COLUMN_NUMBER = 5;
    private static final String TEMP_DIR_LOCATION = System.getProperty("java.io.tmpdir", "./");
    private static final String USER = "user";
    private static final String UNREGISTREDUSERS = "UnRegistred Users";

    private static String SERVICE = "Service";
    private static String COMMA_SEPARATOR = ",";
    private static String SERVICE_COUNT_TITLE = "Service Count of the Day";
    private static String SERVICE_FAILURE_TITLE = "Service failure of the Day";

    private static String USER_RESPONSE_TIME_CHART_NAME = "User_Response_Column_Chart.jpg";
    private static String USER_RESPONSE_TIME_TITLE = "User Response Per service";
    private static String SERVICE_COUNT_CHART_NAME = "Service_Counts_Column_Chart.jpg";
    private static String SERVICE_FAILURE_CHART_NAME = "Service_Failure_Chart.jpg";
    private static String FEATURE_RESPONSE_TIME_TITLE = "Feature Response-Time Audit";
    private static String FEATURE_RESPONSE_TIME_CHART_NAME = "Feature_Response_Column_Chart.jpg";
    private static String TRANSACTION_FAILURE_CHART_NAME = "Transaction_Failure_Response_Column_Chart.jpg";
    private static String TRANSACTION_FAILURE_TITLE = "Transaction Failure Count";
    private static String HOURLY_LOGIN_FREQUENCY_TITLE = "Hourly Unique-Logins Frequency";
    private static String HOURLY_LOGIN_FREQUENCY_CHART_NAME = "Hourly_Login_Frequency.jpg";

    private static final String EMAIL_NOTIFICATION_TEMPLATE_NAME = "config/email-downtime-notification-template.txt";
    private static String templateData = "";

    private static Color BACKGROUND_COLOR = Color.white;
    private static Color BLUE = new Color(78, 131, 197);
    private static Color RED = new Color(194, 78, 79);
    private static Color GREEN = new Color(157, 187, 99);
    private static String vbsFileLocation = "email-sender/outbox/";
    // private static String vbsTemplateFileLocation = "email-sender/Email_Macro_Caller-Template.vbs";

    private static Map<String, Integer> hourlyOffset = new HashMap<String, Integer>();
    static int totalLoginCountService;
    private static List<String> filePaths;
    private static Map<String, String> opCodetoService;
    private static Map<String, Integer> failureToCountMap = new HashMap<String, Integer>();
    private static List<String> pPcode;
    // private static int billPaymentFailure;

    public static Map<String, Double> sHMAverageMap;

    public static int UNREGISTER_USER_CNT = 0;
    public static String UNREGISTER_USER_LOG_MEASSAGE = "This is the UnRegistered User";

    public static void main(String[] args) throws IOException, ParseException {
	hourlyOffset.put("TZ", 3);
	hourlyOffset.put("UG", 3);
	hourlyOffset.put("KE", 3);
	hourlyOffset.put("GH", 0);
	fetchCodes();
	fetchPpCodes();

	List<Activity> activities = getActivitiesFromCSV("TimeAudit.csv");

	System.out.println("Final  Effective Activites are : " + activities.size());
	filePaths = new ArrayList<String>();
	sHMAverageMap = new HashMap<String, Double>();

	prepareServiceCountGraph(activities, filePaths);

	prepareHLFGraph(activities, filePaths);
	prepareTransactionFailuresGraph(activities, filePaths);
	prepareBEMPerformanceGraph(activities, filePaths, sHMAverageMap);
	prepareUserResponseGraph(activities, filePaths, sHMAverageMap);
	preparePieChart(activities, filePaths);
	// prepareAttachment("Error.csv");
	// sendEmail();
	System.out.println("Files Made");

    }

    /*
     * private static void prepareAttachment(String file) throws IOException, ParseException {
     *
     * BufferedReader br1 = FileUtility.getBufferReader(file); StringBuilder serviceData = new StringBuilder();
     *
     * String line; Activity activity1 = null; List<Activity> activities1 = new ArrayList<Activity>(); while ((line = br1.readLine()) != null) {
     * activity1 = getActivity(line);
     *
     * if (activity1 != null) { activities1.add(activity1); }
     *
     * }
     *
     * List<String> sHMCodeList = new ArrayList<String>(5); sHMCodeList.add("BEM08751"); sHMCodeList.add("BEM08744"); sHMCodeList.add("BEM08729");
     * sHMCodeList.add("BEM08777");
     *
     * for (Activity activity : activities1) {
     *
     * if (activity.getOpCode() == null) continue; if ((activity.getFailure() != null) && (isValidDate(activity.getTimeStamp())) &&
     * !(pPcode.contains(activity.getPpErrorCode()))) {
     *
     * if (!(activity.getService().equals("Verify User")) && !sHMCodeList.contains(activity.getResponseCode())){
     *
     * serviceData.append(activity.getServiceName()).append(",").append(activity.getFailure()).append(",").append(
     * failureToCountMap.get(activity.getFailure())).append(activity.getPpErrorCode()).append(","); serviceData.append("\n");
     * FileUtility.writeToFile("ERROR_Summary.csv", serviceData.toString(), true);
     *
     * } }
     *
     * }
     *
     * }
     */

    public static void setColor(PiePlot plot, DefaultPieDataset dataset) {

	GradientPaint gp0 = new GradientPaint(1.0f, 1.0f, new Color(153, 51, 203), 0.3f, 2.1f, Color.lightGray);
	GradientPaint gp1 = new GradientPaint(0.5f, 0.5f, new Color(175, 122, 255), 0.0f, 0.0f, Color.lightGray);
	GradientPaint gp2 = new GradientPaint(0.5f, 0.5f, new Color(102, 204, 153), 0.0f, 0.0f, Color.lightGray);
	GradientPaint gp3 = new GradientPaint(1.0f, 1.0f, Color.gray, 0.3f, 2.1f, Color.lightGray);

	List<Comparable> keys = dataset.getKeys();
	// int aInt;

	for (int i = 0; i < keys.size(); i++) {
	    // aInt = i % this.color.length;
	    if (i == 0) {
		plot.setSectionPaint(keys.get(i), gp0);
		plot.setBackgroundPaint(gp3);
	    }
	    if (i == 1) {
		plot.setSectionPaint(keys.get(i), gp1);
	    }
	    if (i == 2) {
		plot.setSectionPaint(keys.get(i), gp2);
	    }
	}
    }

    private static void preparePieChart(List<Activity> activities, List<String> filePaths) throws IOException {
	String serviceFailureFilePath = getFileName(SERVICE_FAILURE_CHART_NAME, filePaths);
	// DefaultPieDataset dataset = new DefaultPieDataset();
	DefaultPieDataset serviceFailureDataset = createServiceFailureDataset(activities);
	JFreeChart serviceFailureCountChart = ChartFactory.createPieChart(SERVICE_FAILURE_TITLE, serviceFailureDataset, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	// CategoryPlot plot = getPlot(serviceFailureCountChart);
	PiePlot plot = (PiePlot) serviceFailureCountChart.getPlot();
	setColor(plot, serviceFailureDataset);
	// plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
	plot.setNoDataMessage("No data available");
	/*
	 * BufferedImage img = null; try { img = ImageIO.read(new
	 * File("C:/softtag/ProjectWorkspace/workspace_19aug/Log-Graph-Task/Barclays_Bird.png")); } catch (IOException e) { }
	 * plot.setBackgroundImage(img);
	 */

	// plot.setLabelGap(0.02);
	ChartUtilities.saveChartAsJPEG(new File(serviceFailureFilePath), serviceFailureCountChart, 1300, 800);

    }

    private static DefaultPieDataset createServiceFailureDataset(List<Activity> activities) throws IOException {

	Map<String, String> sourceerror = new HashMap<String, String>();
	List<Activity> activityset = new ArrayList<Activity>();
	List<Activity> activitylist = new ArrayList<Activity>();
	DefaultPieDataset dataset = new DefaultPieDataset();
	StringBuilder serviceData = new StringBuilder();
	StringBuilder hostData = new StringBuilder();
	Map<String, List<String>> multimap = new HashMap<String, List<String>>();
	List<String> sHMCodeList = new ArrayList<String>(5);
	sHMCodeList.add("BEM08751");
	sHMCodeList.add("BEM08744");
	sHMCodeList.add("BEM08729");
	sHMCodeList.add("BEM08777");
	sHMCodeList.add("BEM08741");

	serviceData.append("Service Name").append(",").append("Host").append(",").append("Error Count").append(",").append("PP Error Code").append(
		",").append("PP Error Msg").append("\n");

	hostData.append("MobileNo").append(",").append("Country").append(",").append("TimeStamp").append(",").append("SessionId").append(",").append(
		"BEM ErrorCode").append(",").append("Cust Ref Id").append(",").append("Service Name").append(",").append("Host").append(",").append(
		"PP Error Code").append(",").append("PP Error Msg").append("\n");

	for (Activity activity : activities) {

	    if (activity.getOpCode() == null)
		continue;
	    if ((activity.getFailure() != null) && (isValidDate(activity.getTimeStamp())) && (isRequest(activity.getBusinessId()))
		    && !(pPcode.contains(activity.getPpErrorCode()))) {

		if (!(activity.getService().equals("Verify User")) && !sHMCodeList.contains(activity.getResponseCode())) {

		    failureToCountMap = addFailureToMap(failureToCountMap, activity.getFailure());

		    /*
		     * // host error logs.csv
		     * hostData.append(activity.getMobileNo()).append(",").append(activity.getCountry()).append(",").append(activity.getTimeStamp())
		     * .append(",").append(activity.getSessionId()).append(",").append(activity.getBemErrorCode()).append(",").append(
		     * activity.getURN()).append(",").append(activity.getService()).append(",").append(activity.getFailure())
		     * .append(",").append(activity.getPpErrorCode()).append(",").append(activity.getPpErrorDesc()); hostData.append("\n");
		     *
		     * FileUtility.writeToFile("Log_Snippet.csv", hostData.toString(), false);
		     */
		    activityset.add(activity);

		}
	    }

	}
	// Iterate over Map

	for (String failureKey : failureToCountMap.keySet()) {
	    int failureCnt = failureToCountMap.get(failureKey);
	    // create dataset using map
	    dataset.setValue(failureKey + "=" + failureCnt, failureCnt);
	}

	// }
	for (Activity acct : activityset) {

	    if (sourceerror.get(acct.getFailure()) != null) {
		if (!(sourceerror.get(acct.getFailure()).equals(acct.getPpErrorCode()))) {
		    sourceerror.put(acct.getFailure(), acct.getPpErrorCode());

		    if (acct.getFailure().equalsIgnoreCase("shm")) {
			acct.setPpErrorCode(null);
			acct.setPpErrorDesc(null);
			acct.setURN(null);
		    } // error summary
		    serviceData.append(acct.getService()).append(",").append(acct.getFailure()).append(",").append(

		    failureToCountMap.get(acct.getFailure())).append(",").append(acct.getPpErrorCode()).append(",").append(acct.getPpErrorDesc());
		    serviceData.append("\n");
		    FileUtility.writeToFile("ERROR_Summary.csv", serviceData.toString(), false);

		    // host error logs.csv
		    hostData.append(acct.getURN()).append("||").append(acct.getService()).append("||").append(acct.getFailure()).append("||").append(
			    failureToCountMap.get(acct.getFailure())).append("||").append(acct.getPpErrorCode()).append("||").append(
			    acct.getPpErrorDesc());
		    hostData.append("\n");
		    FileUtility.writeToFile("Host_Error_Log.csv", hostData.toString(), false);

		}
	    } else {
		sourceerror.put(acct.getFailure(), acct.getPpErrorCode());
		if (acct.getFailure().equalsIgnoreCase("shm")) {
		    acct.setPpErrorCode(null);
		    acct.setPpErrorDesc(null);
		    acct.setURN(null);
		}

		serviceData.append(acct.getService()).append(",").append(acct.getFailure()).append(",").append(
			failureToCountMap.get(acct.getFailure())).append(",").append(acct.getPpErrorCode()).append(",").append(acct.getPpErrorDesc());
		serviceData.append("\n");
		FileUtility.writeToFile("ERROR_Summary.csv", serviceData.toString(), false); // host error logs.csv

		hostData.append(acct.getURN()).append("||").append(acct.getService()).append("||").append(acct.getFailure()).append("||").append(
			failureToCountMap.get(acct.getFailure())).append("||").append(acct.getPpErrorCode()).append("||").append(
			acct.getPpErrorDesc());
		hostData.append("\n");
		FileUtility.writeToFile("Host_Error_Log.csv", hostData.toString(), false);

	    }

	}

	return dataset;
    }

    private static void fetchCodes() throws IOException {

	BufferedReader br = FileUtility.getBufferReader("Opcodes.csv");
	String line1;
	String line2;
	opCodetoService = new HashMap<String, String>();
	line1 = br.readLine();
	String[] opcodes = line1.split(COMMA_SEPARATOR);
	line2 = br.readLine();
	String[] serviceNames = line2.split(COMMA_SEPARATOR);
	for (int i = 0; opcodes.length > i; i++)
	    opCodetoService.put(opcodes[i].trim(), serviceNames[i].trim());
    }

    private static void fetchPpCodes() throws IOException {

	BufferedReader br = FileUtility.getBufferReader("Ppcodes.csv");
	String line;

	pPcode = new ArrayList<String>();
	line = br.readLine();
	String[] pPcodes = line.split(COMMA_SEPARATOR);

	for (int i = 0; pPcodes.length > i; i++)
	    pPcode.add(pPcodes[i].trim());
    }

    /************************************************ PREPARE ACTIVITY OBJECT *********************************************************/
    private static List<Activity> getActivitiesFromCSV(String csvFile) throws IOException, ParseException {
	BufferedReader br = FileUtility.getBufferReader(csvFile);

	String line;
	List<Activity> activities = new ArrayList<Activity>();
	while ((line = br.readLine()) != null) {
	    Activity activity = getActivity(line);

	    if (activity != null)
		activities.add(activity);
	}

	// Update UnRegister User Count
	for (Activity activity : activities) {
	    if (activity.isUnRegisterUser() && (isRequest(activity.getBusinessId()))) {
		UNREGISTER_USER_CNT++;
	    }
	}
	return filterActivities(activities);
	// return activities;
    }

    private static List<Activity> filterActivities(List<Activity> activities) {
	for (int i = 0; i < activities.size(); i++) {
	    Activity line = null;
	    if (activities.get(i).getService() == null) {
		activities.remove(activities.get(i--));
	    }
	}

	System.out.println("Final list of activities");

	for (Activity activity : activities)
	    System.out.println(activity);

	return activities;

    }

    /*
     * private static int fetchnextline(int i, int maxsize) { if (i < maxsize - 1) { i++; }
     *
     *
     * activities.get(nextindex); i++;
     *
     * return i;
     *
     * }
     */

    private static Activity getActivity(String line) throws ParseException {
	String[] column;
	String[] column1;
	Activity activity = null;
	column = line.split(COMMA_SEPARATOR);
	// Activity activity = null;

	if (!(column[0].trim().equals(""))) {
	    DateFormat readFormat = new SimpleDateFormat("yyyy-MMM-dd hh:mm:ss.SSS");
	    activity = new Activity();
	    System.out.println(column[TIME_STAMP_COLUMN_NUMBER] + "-------" + column[SESSION_ID_COLUMN_NUMBER]);
	    activity.setSession(column[SESSION_ID_COLUMN_NUMBER].trim());
	    activity.setTimeStamp(readFormat.parse(column[TIME_STAMP_COLUMN_NUMBER].trim()));

	    activity.setBusinessId(column[SESSION_ID_COLUMN_NUMBER].substring(column[SESSION_ID_COLUMN_NUMBER].indexOf("BRB") - 2,
		    column[SESSION_ID_COLUMN_NUMBER].indexOf("BRB")));
	    if (activity.getBusinessId().equalsIgnoreCase("TZ"))
		activity.setCountry("Tanzania");
	    System.out.println("****************" + activity.getCountry());

	    activity.setSessionId((column[SESSION_ID_COLUMN_NUMBER].substring(0, column[SESSION_ID_COLUMN_NUMBER].indexOf("BRB") - 3)));
	    // System.out.println("******ssss**********" + activity.getSessionId());
	    // activity.setUnRegisteredUserCount();

	    /*
	     * activity.setCountry(column[SESSION_ID_COLUMN_NUMBER].substring(column[SESSION_ID_COLUMN_NUMBER].indexOf("BRB") - 2,
	     * column[SESSION_ID_COLUMN_NUMBER].indexOf("BRB")));
	     */

	    activity.setMobileNo(column[SESSION_ID_COLUMN_NUMBER].substring(column[SESSION_ID_COLUMN_NUMBER].indexOf("BRB") + 4,
		    (column[SESSION_ID_COLUMN_NUMBER].length())));

	    if (!(column[OPCODE_COLUMN_NUMBER].trim().equals(""))) {
		if (UNREGISTER_USER_LOG_MEASSAGE.equalsIgnoreCase((column[OPCODE_COLUMN_NUMBER]).trim())) {
		    activity.setUnRegisterUser(true);
		} else {
		    activity.setOpCode(column[OPCODE_COLUMN_NUMBER].trim());
		    activity.setResponse(column[RESPONSE_COLUMN_NUMBER].trim());
		    activity.setResponseCode(column[RESPONSE_CODE_COLUMN_NUMBER].trim());
		    activity.setService(opCodetoService.get(activity.getOpCode()));

		    if ((activity.getOpCode().equalsIgnoreCase("OP0603"))) {
			if ((column.length > 8)) {
			    // String categoryCode = column[CATEGORY_COLUMN_NUMBER].trim();
			    if (line.contains("Telephone")) {
				activity.setService("Airtime TopUp");
			    } else if (line.contains("MobileWallet")) {
				activity.setService("MobileWallet");
			    } else {
				activity.setService("Utility Bill payment");
			    }
			}
		    }

		    if (activity.getService() != null) {
			activity.setResponseTime(fetchResponseTime(column[RESPONSE_TIME_COLUMN_NUMBER]));
		    }
		    if (activity.getResponse().equalsIgnoreCase("FAILURE") || activity.getResponse().equalsIgnoreCase("ERROR")) {
			String rescode = activity.getResponseCode();

			if (!(rescode.startsWith("BEM")) && !(rescode.trim().equalsIgnoreCase(""))) {
			    activity.setFailure("SHM");
			    activity.setPpErrorCode("SHM");
			    activity.setPpErrorDesc("SHM");
			    activity.setURN("SHM");

			} else {
			    System.out.println("////////////////" + column.length);
			    if ((column.length > 8)) {
				if (!(column[SERVICE_COLUMN_NUMBER].trim().equals(""))) {

				    int lastIndex = line.lastIndexOf("Error");
				    String newString = line.substring(lastIndex, line.length());
				    column1 = newString.split(COMMA_SEPARATOR);
				    activity.setFailure(column1[FAILURE_COLUMN_NUMBER].trim());
				    activity.setPpErrorCode(column1[PPCODE_COLUMN_NUMBER].trim());
				    activity.setPpErrorDesc(column1[PPCODE_COLUMN_DESCRIPTION].trim());
				    activity.setURN(column1[URN_COLUMN_NUMBER].trim());
				    activity.setBemErrorCode(column1[BEM_ERROR_COLUMN_NUMBER].trim());
				    System.out.println("bem errro code  is :" + activity.getBemErrorCode());
				    // System.out.println("pperror code is :"+activity.getPpErrorCode());
				}
			    }
			}
		    }
		    /*
		     * if((activity.getResponse().trim().equalsIgnoreCase("ERROR")) || (activity.getResponse().trim().equalsIgnoreCase("FAILURE"))){
		     *
		     * FileUtility.writeToFile("Error.csv",line,true); }
		     */
		}

	    }
	    // System.out.println("in get activity+++++++++++++++++++++"+activity.getFailure());
	}

	return activity;
    }

    private static double fetchResponseTime(String responseTime) {
	// String columnBreak[] = responseTime.split("=");
	int msIndex = responseTime.indexOf("ms");
	return Integer.parseInt(responseTime.substring(0, msIndex - 1));

    }

    /************************************************ SERVICE COUNT GRAPH *********************************************************/
    private static void prepareServiceCountGraph(List<Activity> activities, List<String> filePaths) throws IOException {
	String serviceCountFilePath = getFileName(SERVICE_COUNT_CHART_NAME, filePaths);
	DefaultCategoryDataset serviceCountDataset = createServiceCountDataset(activities);
	JFreeChart serviceCountChart = ChartFactory.createBarChart(SERVICE_COUNT_TITLE, SERVICE, SERVICE + "Count", serviceCountDataset,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot = getPlot(serviceCountChart);
	BarRenderer renderer = (BarRenderer) plot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesPaint(0, GREEN);

	ChartUtilities.saveChartAsJPEG(new File(serviceCountFilePath), serviceCountChart, 1300, 800);

    }

    private static DefaultCategoryDataset createServiceCountDataset(List<Activity> activities) throws IOException {

	Map<String, Integer> serviceToCountMap = new HashMap<String, Integer>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	dataset.setValue(UNREGISTER_USER_CNT, SERVICE, UNREGISTREDUSERS);

	for (Activity activity : activities) {

	    if (activity.getOpCode() == null)
		continue;
	    if (isValidDate(activity.getTimeStamp()) && (isRequest(activity.getBusinessId()))) {

		serviceToCountMap = addDataToMap(serviceToCountMap, activity.getService());
		dataset.setValue(serviceToCountMap.get(activity.getService()), SERVICE, activity.getService());
	    }
	}
	return dataset;
    }

    /************************************************ BEM PERFORMANCE GRAPH *********************************************************/
    private static void prepareBEMPerformanceGraph(List<Activity> activities, List<String> filePaths, Map<String, Double> averageMap)
	    throws IOException {

	DefaultCategoryDataset backendPerformance = createBPerformanceCountDataset(activities, averageMap);
	JFreeChart chart = ChartFactory.createBarChart(FEATURE_RESPONSE_TIME_TITLE, SERVICE, "Response Time (sec)", backendPerformance,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot bemPerformancePlot = getPlot(chart);
	BarRenderer renderer = (BarRenderer) bemPerformancePlot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(1, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(2, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));

	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesItemLabelsVisible(1, true);
	renderer.setSeriesItemLabelsVisible(2, true);
	renderer.setSeriesPaint(0, BLUE);
	renderer.setSeriesPaint(1, RED);
	renderer.setSeriesPaint(2, GREEN);
	renderer.setSeriesPaint(3, new Color(128, 100, 159));

	renderer.setItemMargin(.002);

	int columnCount = backendPerformance.getColumnCount();
	String backendPerformanceFile = getFileName(FEATURE_RESPONSE_TIME_CHART_NAME, filePaths);
	int xDimension = columnCount * 100 < 1500 ? 1500 : (columnCount * 100);
	int yDimension = xDimension * 5 / 10;
	ChartUtilities.saveChartAsJPEG(new File(backendPerformanceFile), chart, xDimension, yDimension);

    }

    private static DefaultCategoryDataset createBPerformanceCountDataset(List<Activity> activities, Map<String, Double> averageMap)
	    throws IOException {

	Map<String, List<Double>> serviceToResponseTimesMap = new HashMap<String, List<Double>>();
	// Map<String, List<Double>> serviceUserRespTimesMap = new HashMap<String, List<Double>>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	for (Activity activity : activities) {

	    if (isValidDate(activity.getTimeStamp()) && (isRequest(activity.getBusinessId()))) {

		if (activity.getResponse().equals("SUCCESS")) {

		    serviceToResponseTimesMap = addResponseTimetoService(serviceToResponseTimesMap, activity.getService(), activity.getResponseTime());
		    List<Double> responseTimes = serviceToResponseTimesMap.get(activity.getService());
		    Double averageResponseTime = getAverageFromList(responseTimes);

		    Double ninetyPerc = getNinetyPerc(responseTimes);
		    Double tenPerc = getTenPerc(responseTimes);

		    /*
		     * int responseTimesSize = responseTimes.size(); double numberBelowTen = tenPerc - 0; double numberAboveNinety = responseTimesSize
		     * - ninetyPerc;
		     */
		    // serviceUserRespTimesMap.put(key, value);
		    averageMap.put(activity.getService(), averageResponseTime);
		    dataset.setValue(tenPerc, "Min", activity.getService());
		    dataset.setValue(averageResponseTime, "Average", activity.getService());
		    dataset.setValue(ninetyPerc, "Max", activity.getService());

		}
	    }
	}

	return dataset;

    }

    private static Double getNinetyPerc(List<Double> responseTimes) {
	Collections.sort(responseTimes);
	int length = responseTimes.size();
	int ninetieth = (int) (length * 0.9);
	Double nineth = responseTimes.get(ninetieth);
	return (double) Math.round(nineth * 10) / 10;

    }

    private static Double getTenPerc(List<Double> responseTimes) {
	Collections.sort(responseTimes);
	int length = responseTimes.size();
	int ninetieth = (int) (length * 0.1);
	Double nineth = responseTimes.get(ninetieth);
	return (double) Math.round(nineth * 10) / 10;

    }

    private static Map<String, List<Double>> addResponseTimetoService(Map<String, List<Double>> graphData, String serviceName, double d) {

	List<Double> responseTimes = new ArrayList<Double>();
	if (graphData.get(serviceName) != null) {
	    responseTimes = graphData.get(serviceName);
	}
	responseTimes.add((double) (d / 1000));
	graphData.put(serviceName, responseTimes);
	return graphData;
    }

    private static Double getAverageFromList(List<Double> responseTimes) {

	Double sum = 0.0;
	for (int i = 0; i < responseTimes.size(); i++) {

	    sum += responseTimes.get(i);
	}
	Double avg = (sum / responseTimes.size());

	return (double) Math.round(avg * 10) / 10;
    }

    /************************************************ USER RESPONSE GRAPH *********************************************************/

    private static void prepareUserResponseGraph(List<Activity> activities, List<String> filePaths, Map<String, Double> averageMap)
	    throws IOException {

	DefaultCategoryDataset userBackendPerformance = createUserPerformanceCountDataset(activities, averageMap);
	JFreeChart chart = ChartFactory.createBarChart(USER_RESPONSE_TIME_TITLE, SERVICE, USER + "Count", userBackendPerformance,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot bemPerformancePlot = getPlot(chart);
	BarRenderer renderer = (BarRenderer) bemPerformancePlot.getRenderer();

	renderer.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(1, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer.setSeriesItemLabelGenerator(2, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));

	renderer.setSeriesItemLabelsVisible(0, true);
	renderer.setSeriesItemLabelsVisible(1, true);
	renderer.setSeriesItemLabelsVisible(2, true);
	renderer.setSeriesPaint(0, BLUE);
	renderer.setSeriesPaint(1, RED);
	renderer.setSeriesPaint(2, GREEN);
	renderer.setSeriesPaint(3, new Color(128, 100, 159));

	renderer.setItemMargin(.002);

	int columnCount = userBackendPerformance.getColumnCount();
	String userBackendPerformanceFile = getFileName(USER_RESPONSE_TIME_CHART_NAME, filePaths);
	int xDimension = columnCount * 100 < 1500 ? 1500 : (columnCount * 100);
	int yDimension = xDimension * 5 / 10;
	ChartUtilities.saveChartAsJPEG(new File(userBackendPerformanceFile), chart, xDimension, yDimension);

    }

    private static DefaultCategoryDataset createUserPerformanceCountDataset(List<Activity> activities, Map<String, Double> averageMap)
	    throws IOException {

	Map<String, List<Double>> serviceToResponseTimesMap = new HashMap<String, List<Double>>();

	DefaultCategoryDataset userDataset = new DefaultCategoryDataset();

	for (Activity activity : activities) {

	    if (isValidDate(activity.getTimeStamp()) && (isRequest(activity.getBusinessId()))) {

		if (activity.getResponse().equals("SUCCESS")) {

		    serviceToResponseTimesMap = addUserResponseTimetoService(serviceToResponseTimesMap, activity.getService(), activity
			    .getResponseTime());
		}
	    }

	}

	Set<String> ServiceNameSet = serviceToResponseTimesMap.keySet();
	System.out.println("***Service responce map" + serviceToResponseTimesMap);
	for (String ServiceName : ServiceNameSet) {
	    int userMinCount = 0;
	    int userAvgCount = 0;
	    int userMaxCount = 0;

	    List<Double> responseTimes = serviceToResponseTimesMap.get(ServiceName);

	    for (Double value : responseTimes) {
		if (value >= 0 && value <= 1) {
		    userMinCount++;

		} else if (value > 1 && value <= 5) {
		    userAvgCount++;

		} else if (value > 5) {
		    userMaxCount++;

		}
	    }

	    userDataset.setValue(userMinCount, "Min[0-1 ms]", ServiceName);
	    userDataset.setValue(userAvgCount, "Average[1-5 ms]", ServiceName);
	    userDataset.setValue(userMaxCount, "Max[>5 ms]", ServiceName);

	}

	return userDataset;

    }

    private static Map<String, List<Double>> addUserResponseTimetoService(Map<String, List<Double>> graphData, String serviceName, double d) {

	List<Double> responseTimes = new ArrayList<Double>();
	if (graphData.get(serviceName) != null) {
	    responseTimes = graphData.get(serviceName);
	}
	responseTimes.add((double) (d / 1000));
	graphData.put(serviceName, responseTimes);
	return graphData;
    }

    /************************************************ TRANSACTION FAILURE GRAPH *********************************************************/
    private static void prepareTransactionFailuresGraph(List<Activity> activities, List<String> filePaths) throws IOException {
	DefaultCategoryDataset transactionFailures = createServiceFailureCountDataset(activities);
	JFreeChart tFChart = ChartFactory.createBarChart(TRANSACTION_FAILURE_TITLE, SERVICE, "Failure Count", transactionFailures,
		PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot2 = getPlot(tFChart);
	final CategoryItemRenderer renderer2 = plot2.getRenderer();

	renderer2.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer2.setSeriesItemLabelsVisible(0, true);
	renderer2.setSeriesPaint(0, RED);

	String TransactionFailureFile = getFileName(TRANSACTION_FAILURE_CHART_NAME, filePaths);
	ChartUtilities.saveChartAsJPEG(new File(TransactionFailureFile), tFChart, 900, 700);

    }

    private static DefaultCategoryDataset createServiceFailureCountDataset(List<Activity> activities) throws IOException {

	Map<String, Integer> serviceToFailureCountMap = new HashMap<String, Integer>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	List<String> failureCodeList = new ArrayList<String>(5);
	failureCodeList.add("BEM08751");
	failureCodeList.add("BEM08744");
	failureCodeList.add("BEM08729");
	failureCodeList.add("BEM08777");

	for (Activity activity : activities) {

	    if (isValidDate(activity.getTimeStamp()) && (isRequest(activity.getBusinessId())) && !(pPcode.contains(activity.getPpErrorCode()))) {

		if (activity.getResponse().equals("ERROR") || activity.getResponse().equals("FAILURE")) {
		    if (!(activity.getService().equals("Verify User")) && !failureCodeList.contains(activity.getResponseCode())
			    && (activity.getFailure() != null)) {
			serviceToFailureCountMap = addDataToMap(serviceToFailureCountMap, activity.getService());
			dataset.setValue(serviceToFailureCountMap.get(activity.getService()), SERVICE, activity.getService());
		    }
		}

	    }

	}

	return dataset;
    }

    /************************************************ HOURLY FREQUENCY GRAPH *********************************************************/
    private static void prepareHLFGraph(List<Activity> activities, List<String> filePaths) throws IOException {
	DefaultCategoryDataset hourlyLoginFrequencyDataset = createHLFDataset(activities);
	JFreeChart hLFChart = ChartFactory.createBarChart(HOURLY_LOGIN_FREQUENCY_TITLE, "Time (Hours)", SERVICE + " Count",
		hourlyLoginFrequencyDataset, PlotOrientation.VERTICAL, true, true, false);

	/********************************************** GRAPH FORMATTING ***********************************************************/
	CategoryPlot plot1 = getPlot(hLFChart);

	final CategoryItemRenderer renderer1 = plot1.getRenderer();

	renderer1.setSeriesItemLabelGenerator(0, new StandardCategoryItemLabelGenerator("{2}", NumberFormat.getInstance()));
	renderer1.setSeriesItemLabelsVisible(0, true);

	String HourlyFrequencyFile = getFileName(HOURLY_LOGIN_FREQUENCY_CHART_NAME, filePaths);
	ChartUtilities.saveChartAsJPEG(new File(HourlyFrequencyFile), hLFChart, 1000, 800);

    }

    private static DefaultCategoryDataset createHLFDataset(List<Activity> activities) throws IOException {

	Map<String, Integer> uniqueNumberLoginsPerHourMap = new HashMap<String, Integer>();
	Map<String, Integer> fullDayLogintoCountMap = new HashMap<String, Integer>();

	DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	List<String> mobileNumbersAndHours = new ArrayList<String>();
	List<String> mobileNumbers = new ArrayList<String>();
	for (Activity activity : activities) {

	    if (isValidDate(activity.getTimeStamp()) && (isRequest(activity.getBusinessId()))) {
		if (activity.getService().equals("Login")) {

		    String hour = fetchHour(activity.getTimeStamp(), activity.getCountry());

		    String mobileNoAndHr = activity.getMobileNo() + hour;
		    if (!(mobileNumbersAndHours.contains(mobileNoAndHr))) {
			uniqueNumberLoginsPerHourMap = addDataToMap(uniqueNumberLoginsPerHourMap, hour);
			mobileNumbersAndHours.add(mobileNoAndHr);
		    }
		    System.out.println("checking mobile Number " + activity.getMobileNo() + " Response:"
			    + mobileNumbers.contains(activity.getMobileNo()));
		    if (!(mobileNumbers.contains(activity.getMobileNo()))) {
			fullDayLogintoCountMap = addDataToMap(fullDayLogintoCountMap, hour);
			mobileNumbers.add(activity.getMobileNo());
		    }
		}
	    }
	}

	for (Integer i = 100; i < 124; i++) {
	    String hour = i.toString();
	    hour = hour.substring(1);
	    dataset.setValue(uniqueNumberLoginsPerHourMap.get(hour), SERVICE, hour);
	}

	System.out.println("Full day active users login count: " + totalLoginCount(fullDayLogintoCountMap));
	return dataset;

    }

    private static String fetchHour(Date inputDate, String country) {

	DateFormat writeFormat = new SimpleDateFormat("HH");
	System.out.println(country);
	inputDate = DateUtils.addHours(inputDate, hourlyOffset.get(country));
	String formattedDate = "";
	if (inputDate != null) {
	    formattedDate = writeFormat.format(inputDate);
	}
	return formattedDate;
    }

    private static int totalLoginCount(Map<String, Integer> graphData) {

	Integer loginTotal = 0;
	for (Integer value : graphData.values()) {
	    loginTotal = loginTotal + value; // Can also be done by total += value;
	}

	return loginTotal;

    }

    /************************************************* COMMON METHODS ****************************************************************/
    private static String getFileName(String fileName, List<String> filePaths) {
	String filePath = TEMP_DIR_LOCATION + fileName;
	filePaths.add(filePath);
	System.out.println(filePath);
	return filePath;
    }

    private static Map<String, Integer> addDataToMap(Map<String, Integer> graphData, String serviceName) {

	int serviceCount;
	if (graphData.get(serviceName) != null) {
	    serviceCount = graphData.get(serviceName);
	    serviceCount++;
	} else {
	    serviceCount = 1;

	}
	graphData.put(serviceName, serviceCount);
	return graphData;
    }

    private static Map<String, Integer> addFailureToMap(Map<String, Integer> graphData, String failurename) {

	int failureCount;
	if (graphData.get(failurename) != null) {
	    failureCount = graphData.get(failurename);
	    failureCount++;
	} else {
	    failureCount = 1;

	}
	graphData.put(failurename, failureCount);
	return graphData;
    }

    private static CategoryPlot getPlot(JFreeChart chart) {
	CategoryPlot plot = (CategoryPlot) chart.getPlot();
	CategoryAxis xAxis3 = (CategoryAxis) plot.getDomainAxis();

	xAxis3.setCategoryLabelPositions(CategoryLabelPositions.UP_45);

	TextTitle title = chart.getTitle();
	Font titleFont = new Font("TimesRoman", Font.BOLD, 25);
	title.setFont(titleFont);
	chart.setTitle(title);
	BarRenderer renderer = (BarRenderer) plot.getRenderer();
	renderer.setMaximumBarWidth(0.03);

	renderer.setDrawBarOutline(true);
	renderer.setBarPainter(new StandardBarPainter());
	renderer.setShadowVisible(false);
	renderer.setSeriesPaint(0, BLUE);
	plot.setRangeGridlinePaint(Color.gray);
	plot.setRangeGridlinesVisible(true);
	chart.setBackgroundPaint(BACKGROUND_COLOR);
	plot.setBackgroundPaint(BACKGROUND_COLOR);
	return plot;
    }

    private static boolean isValidDate(Date inputDate) {

	/*
	 * Date yesterday = DateUtils.addDays(new Date(), -1); DateFormat onlyDate = new SimpleDateFormat("yyyy-MMM-dd"); String yesterdayFormatted =
	 * onlyDate.format(yesterday);
	 *
	 * String inputFormatted = onlyDate.format(inputDate);
	 *
	 * if (!(inputFormatted.equals(yesterdayFormatted))) { return false; }
	 */

	return true;
    }

    private static boolean isRequest(String businessId) {
	/*
	 * if (!businessId.equalsIgnoreCase("TZ")) {
	 *
	 * return false; }
	 */

	return true;
    }

    /**************************************************
     * send Email
     *
     * @throws FileNotFoundException
     **********************************************************************/
    private static void sendEmail() throws FileNotFoundException {

	/*
	 * if (isValid(eventWatch, logMessage)) {
	 *
	 * //LOGGER.info(" The valid error codes- " + logMessage); System.out.println("++++++++++ valid error codes");
	 *
	 * } else {
	 */

	Properties props = new Properties();
	InputStream inputStream = new FileInputStream("log-graph-task-config.properties");
	// InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("log-graph-task-config.properties");
	try {
	    props.load(inputStream);
	    inputStream.close();
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

	String to = props.getProperty("user.name");
	String password = props.getProperty("user.password");
	// LOGGER.debug("\n ======================================== \n");
	// LOGGER.debug("\nWrite Email VBS file -->" + logMessage);
	// Send Email

	// EmailMessage message = eventWatch.getEmailMessage();

	String subject = "SHM TZ PROD | Services response reports 29-09-2014";
	// String bodyText = FileUtility.readContents(EMAIL_NOTIFICATION_TEMPLATE_NAME);
	// String bodyText
	// bodyText = bodyText.replaceAll(SYSTEM_TAG, message.getSystem());
	// bodyText = bodyText.replaceAll(SERVICE_TAG, serviceName);

	String vbsFileName = vbsFileLocation + "Email-Notification.vbs";

	String ErrorSummaryFile = "./ERROR_Summary.csv";
	String logSnippetFile = "./Log_Snippet.csv";

	try {
	    templateData = IOUtils.toString(new FileInputStream("email-sender/Email_Macro_Caller-Template.vbs"));
	} catch (Exception e) {
	    // LOGGER.fatal(e.getMessage(), e);
	    e.printStackTrace();
	}

	String sendEmailCall = "xlApp.Run \"SendDowntimeEmail\", \"" + props.getProperty("TO_RECIPIENTS") + "\", \""
		+ props.getProperty("CC_RECIPIENTS") + "\", \"" + props.getProperty("") + "\", \"" + subject + "\", \"" + "null" + "\", \""
		+ props.getProperty("IMPORTANCE") + "\", \"" + ErrorSummaryFile + "\", \"" + logSnippetFile + "\"";

	// LOGGER.info("Update Email script - Add [" + sendEmailCall + "]");

	String data = templateData.replace("'SEND_EMAIL_CALL", sendEmailCall);
	FileUtility.writeToFile(vbsFileName, data, false);

    }

}
