package com.barclays.bmg.log.graphs;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.List;

import com.Ostermiller.util.ConcatReader;

public class FileMergeUtil {

    public void merge(String[] sourceFiles, String destinationFile) throws IOException {
	FileReader in;
	ConcatReader concatReader = new ConcatReader();

	for (int i = 0; i < sourceFiles.length; i++) {
	    in = new FileReader(sourceFiles[i]);
	    concatReader.addReader(in);
	}

	concatReader.lastReaderAdded();

	FileWriter fw = new FileWriter(destinationFile);

	int c;
	while ((c = concatReader.read()) != -1) {
	    fw.write((char) c);
	}
	fw.close();
	concatReader.close();
    }

    public static void main(String args[]) {
	try {

	    DirectoryListUtil listFilesUtil = new DirectoryListUtil();

	    // final String directoryName = "C://softtag//Log-Files";
	    //final String directoryName = "C://softtag//ProjectWorkspace//workspace_SCB_Latest//Log-Graph-Task//backup//month";
	    final String directoryName ="C://softtag//Mayuri//Server_1.txt";
	    listFilesUtil.listFilesAndFilesSubDirectories(directoryName);
	    System.out.println("Done");

	    List<String> bemFileName = listFilesUtil.getBemFileName();
	    String[] bemArray = new String[bemFileName.size()];
	    bemFileName.toArray(bemArray);
	    List<String> auditFileName = listFilesUtil.getAuditFileName();
	    String[] auditArray = new String[auditFileName.size()];
	    auditFileName.toArray(auditArray);

	    new FileMergeUtil().merge(bemArray, "C:\\softtag\\BEM.csv");
	    new FileMergeUtil().merge(auditArray, "C:\\softtag\\TimeAudit.csv");

	    // Code to append the column number to file

	    RandomAccessFile bemTat = new RandomAccessFile("C:\\softtag\\BEM.csv", "rws");
	    RandomAccessFile timeAudit = new RandomAccessFile("C:\\softtag\\TimeAudit.csv", "rws");

	    byte[] text = new byte[(int) bemTat.length()];
	    bemTat.readFully(text);
	    bemTat.seek(0);
	    bemTat
		    .writeBytes("Time_stamp,Mode,Mobile_Number,Service,Response,Response_Time,Ref_No,BEM_Error_Code,Source,PP_Error_Code,PP_Error_Msg,Con_Unique_Ref_No");

	    bemTat.write(text);
	    bemTat.close();

	    byte[] text1 = new byte[(int) timeAudit.length()];
	    timeAudit.readFully(text1);
	    timeAudit.seek(0);
	    timeAudit
		    .writeBytes("Time_stamp,Mode,Mobile_Number,Service,Response,Response_Time,Ref_No,BEM_Error_Code,Source,PP_Error_Code,PP_Error_Msg,Con_Unique_Ref_No");
	    timeAudit.write(text);
	    timeAudit.close();

	    System.out.println("Done");
	    System.out.println("++++++++++++");
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

}