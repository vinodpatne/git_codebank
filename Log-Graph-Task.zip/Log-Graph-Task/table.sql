use LOG_MANAGEMENT_DB;

drop table	TIME_AUDIT;
 CREATE TABLE TIME_AUDIT (
		  Transaction_ID VARCHAR(50) NOT NULL PRIMARY KEY,
          Time_Stamp VARCHAR(50),
		  Session_Id VARCHAR(50),
		  Business_ID VARCHAR(5),
		  Mobile_Number VARCHAR(50),
		  Opcode VARCHAR(6),
		  Response VARCHAR(50),
		  Respose_Code VARCHAR(30),
		  SHM_Response_Time INT(6),
		  BEM_Response_Time INT(6)
		);

drop table BEM_SERVICE_BREAKUP;
 CREATE TABLE BEM_SERVICE_BREAKUP(
		 Transaction_ID VARCHAR(50) NOT NULL UNIQUE,
		 Time_Stamp VARCHAR(50),
		 Break_Up VARCHAR(500),
		INDEX (Transaction_ID),
        FOREIGN KEY (Transaction_ID)  REFERENCES TIME_AUDIT(Transaction_ID)  ON DELETE CASCADE

 );



Transaction_ID,Time_Stamp,Session_Id,Business_ID,Mobile_Number,Opcode,Response,Respose_Code,SHM_Response_Time,BEM_Response_Time
Transaction_ID,Time_Stamp,Break_Up


select * from BEM_SERVICE_BREAKUP;